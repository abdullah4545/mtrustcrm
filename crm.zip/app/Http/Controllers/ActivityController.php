<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\ActivityTravel;
use App\Models\ActivityExpense;
use App\Models\Department;
use App\Models\ExpenseType;
use App\Models\Organization;
use App\Models\OrganizationContact;
use App\Models\User;
use App\Models\Vehicle;
use App\Support\CrmAccess;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Yajra\DataTables\DataTables;
use App\Services\ActivityBillReview as Bills;

class ActivityController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('permission:activity.view_all|activity.view_branch|activity.view_self')
            ->only(['index','datatable','organizations','departments','vehicles','expenseTypes','staffs','organizationDepartments','organizationContacts']);
        // The /activities/{id} route is the Activity EDIT screen in this CRM.
        // Do not require activity.details.view here; staff with activity.edit must be able
        // to open their own/visible activity for editing. findVisible() still enforces
        // self/branch/all data scope, and update is protected by the same permission.
        $this->middleware('permission:activity.edit')->only(['show','update']);
        $this->middleware('permission:activity.create')->only(['quickCreate','quickStore','store']);
        $this->middleware('permission:activity.delete')->only(['destroy']);
        $this->middleware('permission:activity.approve')->only(['review']);
        $this->middleware('permission:activity.bulk_review|activity.payment.manage')->only(['bulkAction']);
    }

    private function isAdmin(): bool
    {
        $u = Auth::user();
        return (bool) $u?->can('activity.approve');
    }

    private function isSuperAdmin(): bool
    {
        return (bool) Auth::user()?->hasRole('superadmin');
    }

    /** Users with this permission are not limited to one successful edit. */
    private function canMultipleEdit(): bool
    {
        return (bool) Auth::user()?->hasPermissionTo('activity.multiple_edit');
    }

    private function isLocked(Activity $activity): bool
    {
        return in_array(strtolower((string) $activity->status), ['approved', 'rejected'], true);
    }

    private function ensureUnlockedOrSuperAdmin(Activity $activity, string $action = 'change'): void
    {
        if (!$this->isLocked($activity) || $this->isSuperAdmin()) return;

        throw ValidationException::withMessages([
            'activity' => 'Approved or rejected activities are locked. Only Super Admin can '.$action.' them.',
        ]);
    }

    /**
     * Roles that may create an activity for another staff member and
     * manually choose the activity date/time. Regular staff always
     * create for themselves with the current system time.
     */
    private function canManageActivityEntry(): bool
    {
        return (bool) Auth::user()?->can('activity.create_for_others');
    }

    private function manageableStaffs()
    {
        $u = Auth::user();
        if (!$this->canManageActivityEntry()) return collect();

        $query = User::where('status', 1);
        if (!$u?->can('activity.view_all')) $query->where('branch_id', $u->branch_id);
        return $query->orderBy('name')->limit(300)->get(['id','name','branch_id']);
    }

    private function visibleQuery()
    {
        $u = Auth::user();
        $q = Activity::query()->withCount('billHistories')->with(['creator:id,name','lastEditor:id,name','travels','expenses']);
        if ($u->can('activity.view_all')) return $q;
        return $q->where('created_by',$u->id);
    }

    private function findVisible(int $id): Activity
    {
        return $this->visibleQuery()->with(['travels.lastEditor','expenses.lastEditor'])->findOrFail($id);
    }

    public function index(){
        $u = Auth::user();
        $staffs = $u->can('activity.view_all') && $u->can('staff.filter')
            ? User::where('status',1)->orderBy('name')->get(['id','name'])
            : User::whereKey($u->id)->get(['id','name']);
        $showStaffColumn = $u->can('activity.view_all');
        $showStatus = $u->canAny(['activity.status.view','activity.approve','activity.bulk_review']);
        $showEditAudit = false;
        $canBulkReview = $u->can('activity.bulk_review');
        $canManagePayment = $u->can('activity.payment.manage');// TA/DA edit audit is shown per row inside the activity form.
        // TA/DA edit status is intentionally not shown on the Activity List.
        return view('backend.content.activity.index', compact('staffs', 'showStaffColumn', 'showEditAudit', 'showStatus', 'canBulkReview', 'canManagePayment'));
    }

    public function datatable(Request $request)
    {
        $query = $this->visibleQuery()
            ->latest('activity_at')->latest('id');
        if (Auth::user()->can('activity.view_all') && Auth::user()->can('staff.filter') && $request->filled('created_by')) $query->where('created_by', $request->integer('created_by'));
        if (Auth::user()->can('activity.view_all') && $request->filled('branch_id')) $query->where('branch_id', $request->integer('branch_id'));
        if (Auth::user()->canAny(['activity.approve','activity.bulk_review'])) $query->with('reviewer:id,name');
        $canViewAll = Auth::user()->can('activity.view_all');
        $showStatus = Auth::user()->canAny(['activity.status.view','activity.approve','activity.bulk_review']);
        $status = $showStatus ? (string) $request->input('status', 'all') : 'all';
        abort_unless(in_array($status, ['all','pending','approved','rejected'], true), 422, 'Invalid activity status.');
        if (!$canViewAll) $query->whereIn('status', ['pending','rejected']);
        if ($status !== 'all') $query->where('status', $status);
        if ($request->filled('payment_status')) $query->where('payment_status',$request->string('payment_status'));
        if ($request->filled('date')) $query->whereDate('date', $request->date('date'));
        else {
            if ($request->filled('from_date')) $query->whereDate('date','>=',$request->date('from_date'));
            if ($request->filled('to_date')) $query->whereDate('date','<=',$request->date('to_date'));
        }
        $summaryQuery=clone $query;
        $summary=['activity_count'=>(clone $summaryQuery)->count(),'total_ta'=>(clone $summaryQuery)->sum('ta'),'total_da'=>(clone $summaryQuery)->sum('da'),'grand_total'=>(clone $summaryQuery)->sum('total')];
        return DataTables::of($query)->with('summary',$summary)
            ->addIndexColumn()
            ->addColumn('select', fn($row) => '<input type="checkbox" class="activity-check form-check-input" value="'.$row->id.'">')
            ->addColumn('staff_name', fn($row) => e($row->creator?->name ?? '-'))
            ->addColumn('organization_contact', function($row) {
                $org = e($row->organization_name ?: '-');
                $contact = trim((string) ($row->contact_person ?? ''));
                return $contact !== '' ? $org.'<br><strong>'.e($contact).'</strong>' : $org;
            })
            ->editColumn('date', fn($row) => optional($row->activity_at)->timezone('Asia/Dhaka')->format('d M Y, h:i A') ?? optional($row->date)->format('d M Y'))
            ->addColumn('created_display', function($row) {
                $when = ($row->activity_at ?? $row->date)?->copy()->timezone('Asia/Dhaka')->format('d M Y, h:i A') ?? '-';
                $html = '<div class="crm-created">'.e($when).'</div>';
                if (Auth::user()->can('activity.view_all')) {
                    $html .= '<span class="crm-staff-badge"><i class="feather-user" aria-hidden="true"></i> '.e($row->creator?->name ?? '-').'</span>';
                }
                if($row->tour_type==='tour') $html.='<div class="mt-1"><span class="badge bg-primary">Tour</span></div>';
                return $html;
            })
            ->addColumn('visit_output', fn($row) => nl2br(e($row->work_details ?: '-')))
            ->addColumn('route_display', fn($row) => \App\Support\ActivityDisplay::route($row,true,true))
            ->addColumn('amount_display', function($row) {
                $format = fn($v) => rtrim(rtrim(number_format((float)$v,2,'.',','),'0'),'.');
                return '<div class="crm-amount">TA Payable: '.$format($row->ta).'<br>DA Hotel and Others: '.$format($row->da).'<br>Claimed: '.$format($row->claimed_total).'<br><span class="text-danger">Deducted: '.$format($row->deducted_total).'</span><br><strong>Payable: '.$format($row->total).'</strong></div>';
            })
            ->addColumn('tour_type', fn($row) => e($row->tour_type==='tour'?'Tour':'Local Tour'))
            ->addColumn('payment_status', function($row){ $map=['unpaid'=>'secondary','waiting_for_payment'=>'warning','paid'=>'success']; $label=['unpaid'=>'Unpaid','waiting_for_payment'=>'Waiting for Payment','paid'=>'Paid']; return '<span class="badge bg-'.($map[$row->payment_status]??'secondary').'">'.e($label[$row->payment_status]??ucfirst($row->payment_status)).'</span>'.($row->paid_at?'<div class="small text-muted mt-1">'.$row->paid_at->timezone('Asia/Dhaka')->format('d M Y, h:i A').'</div>':''); })
            ->addColumn('status', function ($row) {
                $html = '<span class="badge bg-'.($row->status==='approved'?'success':($row->status==='rejected'?'danger':'secondary')).'">'.e($row->status).'</span>';
                if ($row->status==='rejected' && $row->review_note) $html .= '<div class="small text-danger mt-1">'.e($row->review_note).'</div>';
                if (Auth::user()->canAny(['activity.approve','activity.bulk_review']) && in_array($row->status, ['approved','rejected'], true)) {
                    $label = $row->status==='approved' ? 'Approved by: ' : 'Rejected by: ';
                    $html .= '<div class="small text-muted mt-1 activity-reviewer"><strong>'.e($label).'</strong>'.e($row->reviewer?->name ?? 'Unknown / legacy').'</div>';
                    if ($row->reviewed_at) $html .= '<div class="small text-muted">'.e($row->reviewed_at->timezone('Asia/Dhaka')->format('d M Y, h:i A')).'</div>';
                }
                return $html;
            })
            ->addColumn('edit_history', function($row) {
                if (!Auth::user()->hasPermissionTo('activity.multiple_edit')) return '';
                $count = (int) ($row->edit_count ?? 0);
                if ($count < 1) return '<span class="badge bg-light text-dark">Not Edited</span>';
                $when = $row->last_edited_at ? $row->last_edited_at->timezone('Asia/Dhaka')->format('d M Y, h:i A') : '-';
                $by = e($row->lastEditor?->name ?? '-');
                return '<span class="badge bg-info-subtle text-info">Edited '.$count.'x</span><div class="small text-muted mt-1">'.$by.'<br>'.$when.'</div>';
            })
            ->addColumn('action', function($row){
                $user = Auth::user();
                $locked = $this->isLocked($row);
                $superAdmin = $this->isSuperAdmin();
                $canModifyLocked = $row->status!=='rejected' && (!$locked || $superAdmin);
                $billFrozen=$row->payment_status==='paid'||(int)$row->bill_histories_count>0;

                $html='<div class="activity-actions"><a class="btn btn-sm btn-outline-primary" href="'.route('activities.bill-review',$row->id).'">Bill / History</a>';

                $canMultipleEdit = $user->hasPermissionTo('activity.multiple_edit');
                $editCount = (int) ($row->edit_count ?? 0);

                if ($user->can('activity.edit') && $canModifyLocked && !$billFrozen) {
                    $html.='<a href="'.route('activities.show',$row->id).'" class="btn btn-sm btn-primary">Edit</a>';
                }

                if ($canMultipleEdit) {
                    if ($editCount > 0) {
                        $lastEdited = $row->last_edited_at ? $row->last_edited_at->timezone('Asia/Dhaka')->format('d M Y, h:i A') : '-';
                        $html.='<span class="badge bg-info-subtle text-info align-self-center" title="Last edited: '.e($lastEdited).'">Edited '.$editCount.'x</span>';
                    } else {
                        $html.='<span class="badge bg-light text-dark align-self-center">Not Edited</span>';
                    }
                }

                // Pending activities can be reviewed by normal approvers. Once reviewed,
                // only Super Admin may change the approval decision.
                if ($user->can('activity.approve') && (!$locked || $superAdmin)) {
                    if ($row->status !== 'approved' && $row->status !== 'rejected') {
                        $html.='<button class="btn btn-sm btn-success btn-review" data-id="'.$row->id.'" data-status="approved">Approve</button>';
                    }
                    if ($row->status !== 'rejected') {
                        $html.='<button class="btn btn-sm btn-warning btn-review" data-id="'.$row->id.'" data-status="rejected">Reject</button>';
                    }
                }

                if ($user->can('activity.delete') && $canModifyLocked && !$billFrozen) {
                    $html.='<button class="btn btn-sm btn-danger btn-delete" data-id="'.$row->id.'">Delete</button>';
                }

                if ($locked && !$superAdmin) {
                    $html.='<span class="badge bg-light text-dark align-self-center"><i class="feather-lock"></i> Locked</span>';
                }

                if($row->tour_type==='tour') {
                    $html.='<span class="badge bg-info">'.($row->tour_ended_at?'Ended: '.e($row->tour_ended_at->format('d M Y h:i A')):'Tour running').'</span>';
                    if(!$row->tour_ended_at && $row->status!=='rejected' && $user->can('activity.tour.manage')) $html.='<form method="POST" action="'.route('activities.tour-end',$row->id).'">'.csrf_field().'<input type="datetime-local" name="tour_ended_at" class="form-control form-control-sm" required min="'.e(($row->activity_at??$row->date)->format('Y-m-d\TH:i')).'"><button class="btn btn-sm btn-outline-info">End Tour</button></form>';
                }
                return $html.'</div>';
            })->rawColumns(['visit_output','created_display','route_display','amount_display','select','organization_contact','payment_status','status','edit_history','action'])->make(true);
    }

    public function endTour(Request $request,$id)
    {
        abort_unless(auth()->user()->can('activity.tour.manage'),403);
        $data=$request->validate(['tour_ended_at'=>'required|date']);
        DB::transaction(function()use($id,$data){
            $a=$this->visibleQuery()->whereKey($id)->lockForUpdate()->firstOrFail();
            if($a->tour_type!=='tour'||$a->tour_ended_at||$a->status==='rejected') throw ValidationException::withMessages(['tour_ended_at'=>'This tour cannot be ended.']);
            $end=\Carbon\Carbon::parse($data['tour_ended_at'],'Asia/Dhaka');
            if($end->lt($a->activity_at??$a->date)||$end->gt(now('Asia/Dhaka'))) throw ValidationException::withMessages(['tour_ended_at'=>'End time must be between tour start and now.']);
            $a->tour_ended_at=$end;$a->tour_ended_by=auth()->id();$a->save();
        });
        return back()->with('message','Tour ended successfully.');
    }

    public function quickCreate()
    {
        return view('backend.content.activity.quick_create', [
            'isAdmin' => $this->isAdmin(),
            'canManageActivityEntry' => $this->canManageActivityEntry(),
            'staffs' => $this->manageableStaffs(),
            'expenseTypes' => ExpenseType::where('status',1)->orderBy('sort_order')->orderBy('name')->get(),
        ]);
    }

    public function vehicles(){ return response()->json(Vehicle::select('id','title')->where('status','active')->orderBy('title')->get()); }
    public function expenseTypes(){ return response()->json(ExpenseType::select('id','name')->where('status',1)->orderBy('sort_order')->orderBy('name')->get()); }
    public function staffs(){ abort_unless($this->canManageActivityEntry(),403); return response()->json($this->manageableStaffs()); }

    public function organizationDepartments($organization_id)
    {
        CrmAccess::ensureOrganizationAllowed(Organization::findOrFail($organization_id));
        return response()->json(OrganizationContact::with('department:id,title')->where('organization_id',$organization_id)->whereNotNull('department_id')->where('status','active')->get()->pluck('department')->filter()->unique('id')->values());
    }

    public function organizationContacts(Request $request,$organization_id)
    {
        CrmAccess::ensureOrganizationAllowed(Organization::findOrFail($organization_id));
        $q = OrganizationContact::select('id','name','phone','designation_id','department_id')->with('designation:id,title')->where('organization_id',$organization_id)->where('status','active');
        if ($request->filled('department_id')) $q->where('department_id',$request->integer('department_id'));
        return response()->json($q->orderByDesc('is_primary')->orderBy('name')->get());
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'staff_id'=>'nullable|exists:users,id','activity_at'=>'nullable|date','organization_id'=>'required|exists:organizations,id',
            'work_details'=>'required|string','remarks'=>'nullable|string','status'=>'nullable|in:pending,approved,rejected',
            'tour_ended_at'=>'nullable|date','tour_type'=>'nullable|in:local_tour,tour','travels.*.note'=>'nullable|string|max:500',
            'travels'=>'nullable|array','travels.*.id'=>'nullable|integer','travels.*.entry_at'=>'required_with:travels|date_format:Y-m-d\TH:i','travels.*.from_location'=>'required_with:travels|string|max:255','travels.*.to_location'=>'required_with:travels|string|max:255',
            'travels.*.vehicle'=>'nullable|string|max:255','travels.*.distance'=>'required_with:travels|numeric|min:0.01','travels.*.cost'=>'nullable|numeric|min:0',
            'travels.*.existing_image_url'=>'nullable|string|max:500','travels.*._edited'=>'nullable|boolean','travels.*.image'=>'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'expenses'=>'nullable|array','expenses.*.id'=>'nullable|integer','expenses.*.entry_at'=>'required_with:expenses|date_format:Y-m-d\TH:i','expenses.*.expense_type_id'=>'required_with:expenses|exists:expense_types,id','expenses.*.amount'=>'nullable|numeric|min:0','expenses.*.note'=>'nullable|string|max:500',
            'expenses.*.existing_image_url'=>'nullable|string|max:500','expenses.*._edited'=>'nullable|boolean','expenses.*.image'=>'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
        ]);
    }

    private function storeActivityImage($file, string $group): ?string
    {
        if (!$file || !$file->isValid()) return null;
        $folder = 'uploads/activity/' . $group;
        $absolute = public_path($folder);
        if (!is_dir($absolute)) mkdir($absolute, 0775, true);
        $name = now('Asia/Dhaka')->format('YmdHis') . '_' . uniqid() . '.' . strtolower($file->getClientOriginalExtension());
        $file->move($absolute, $name);
        return 'public/' . $folder . '/' . $name;
    }

    private function deleteActivityImage(?string $storedPath): void
    {
        if (!$storedPath) return;
        $relative = preg_replace('#^/?public/#', '', str_replace('\\', '/', $storedPath));
        if (!str_starts_with($relative, 'uploads/activity/')) return;
        $absolute = public_path($relative);
        if (is_file($absolute)) @unlink($absolute);
    }

    private function ensureEditable(Activity $activity): void
    {
        // Approval is a hard lock. Having activity.edit or activity.approve is not enough;
        // only the protected superadmin role may override an approved/rejected activity.
        $this->ensureUnlockedOrSuperAdmin($activity, 'edit');

        if ($this->isAdmin()) return;

        $activityDate = ($activity->activity_at ?? $activity->created_at ?? $activity->date)?->timezone('Asia/Dhaka')->toDateString();
        if ($activityDate !== now('Asia/Dhaka')->toDateString()) {
            throw ValidationException::withMessages(['activity'=>'Previous day activities can only be edited by Admin or Super Admin.']);
        }
    }

    private function saveActivity(Activity $activity, Request $request): Activity
    {
        if ($activity->exists) {
            if($activity->status==='rejected') throw ValidationException::withMessages(['activity'=>'Rejected activities cannot be changed.']);
            $this->ensureEditable($activity);
            if($activity->payment_status==='paid' || Bills::hasHistory($activity)) throw ValidationException::withMessages(['activity'=>'Reviewed or paid bills cannot be rewritten. Use Bill / History to correct a deduction.']);
        }
        $data = $this->validated($request);
        $expenseRows = collect($data['expenses'] ?? [])->filter(fn($r) => !empty($r['expense_type_id']) || (float)($r['amount'] ?? 0) > 0);
        $travelRows = collect($data['travels'] ?? [])->filter(fn($r) => filled($r['from_location'] ?? null) || filled($r['to_location'] ?? null) || (float)($r['distance'] ?? 0) > 0 || (float)($r['cost'] ?? 0) > 0);
        if ($expenseRows->isNotEmpty() && $travelRows->isEmpty()) throw ValidationException::withMessages(['expenses' => 'DA cannot be submitted until the corresponding TA/travel entry is created.']);
        $u = Auth::user();
        $owner = $u;
        if ($this->canManageActivityEntry() && !empty($data['staff_id'])) {
            $allowedStaff = $this->manageableStaffs()->firstWhere('id', (int) $data['staff_id']);
            abort_unless($allowedStaff, 403, 'You cannot create an activity for this staff member.');
            $owner = User::findOrFail($allowedStaff->id);
        }

        $org = Organization::findOrFail($data['organization_id']);
        if ($org) CrmAccess::ensureOrganizationAllowed($org, $owner);

        $travels = collect($data['travels'] ?? [])->filter(fn($r) => filled($r['from_location'] ?? null) || filled($r['to_location'] ?? null) || (float)($r['cost'] ?? 0)>0)->values();
        $expenses = collect($data['expenses'] ?? [])->filter(fn($r) => !empty($r['expense_type_id']) || (float)($r['amount'] ?? 0)>0)->values();

        $ta = $travels->sum(fn($r)=>(float)($r['cost']??0));
        $da = $expenses->sum(fn($r)=>(float)($r['amount']??0));
        $now = now('Asia/Dhaka');
        if (!$activity->exists && empty($data['activity_at'])) {
            throw ValidationException::withMessages(['activity_at' => 'Please select an activity date and time.']);
        }
        if ($activity->exists && !$u->hasPermissionTo('activity.view_all')) {
            $activityAt = ($activity->activity_at ?? $activity->created_at ?? $activity->date)->copy()->timezone('Asia/Dhaka');
        } else {
            $activityAt = !empty($data['activity_at'])
                ? \Carbon\Carbon::parse($data['activity_at'], 'Asia/Dhaka')
                : ($activity->activity_at ?? $activity->created_at ?? $now)->copy()->timezone('Asia/Dhaka');
        }

        if($activity->exists && $activity->tour_type==='tour' && !$activityAt->equalTo($activity->activity_at??$activity->date)) throw ValidationException::withMessages(['activity_at'=>'Tour start time cannot be changed once started.']);
        $oldTravelImages = $activity->exists ? $activity->travels->pluck('image_url')->filter()->values()->all() : [];
        $oldExpenseImages = $activity->exists ? $activity->expenses->pluck('image_url')->filter()->values()->all() : [];
        $wasExisting = $activity->exists;
        $claimOwnerId=(int)$activity->created_by;

        return DB::transaction(function () use ($activity,$data,$org,$owner,$u,$travels,$expenses,$ta,$da,$now,$activityAt,$oldTravelImages,$oldExpenseImages,$wasExisting,$claimOwnerId) {
            if($activity->exists){
                $locked=Activity::whereKey($activity->id)->lockForUpdate()->firstOrFail();
                if($locked->status==='rejected') throw ValidationException::withMessages(['activity'=>'Rejected activities cannot be changed.']);
                $this->ensureEditable($locked);
                $activity->tour_type=$locked->tour_type;
                $activity->tour_ended_at=$locked->tour_ended_at;
                $activity->tour_ended_by=$locked->tour_ended_by;
                if($locked->payment_status==='paid'||Bills::hasHistory($locked)) throw ValidationException::withMessages(['activity'=>'This bill was reviewed while you were editing. Reload and use Bill / History.']);
            }

            $tourType=$data['tour_type']??($activity->tour_type??'local_tour');
            if($tourType!==($activity->tour_type??'local_tour')) abort_unless($u->can('activity.tour.manage'),403,'Tour permission is required.');
            if($activity->exists && $activity->tour_type==='tour' && $tourType!=='tour') throw ValidationException::withMessages(['tour_type'=>'A started tour cannot be removed.']);
            if($tourType==='tour' && $activityAt->gt($now)) throw ValidationException::withMessages(['activity_at'=>'Tour start cannot be in the future.']);
            $activity->tour_type=$tourType;
            if(!empty($data['tour_ended_at'])) {
                abort_unless($u->can('activity.tour.manage'),403,'Tour permission is required.');
                $end=\Carbon\Carbon::parse($data['tour_ended_at'],'Asia/Dhaka');
                if($tourType!=='tour'||$end->lt($activityAt)||$end->gt($now)) throw ValidationException::withMessages(['tour_ended_at'=>'Tour end must be between activity start and now.']);
                if($activity->tour_ended_at && !$end->equalTo($activity->tour_ended_at)) throw ValidationException::withMessages(['tour_ended_at'=>'Tour has already ended.']);
                $activity->tour_ended_at=$end;$activity->tour_ended_by=$u->id;
            }
            $activity->fill([
                'organization_id'=>$org?->id,'organization_name'=>$org?->name,'department_id'=>null,'department'=>null,
                'contact_id'=>null,'contact_person'=>null,'work_details'=>$data['work_details']??null,
                'from_location'=>$travels->pluck('from_location')->filter()->implode(' | '),
                'to_location'=>$travels->pluck('to_location')->filter()->implode(' | '),
                'vehicle'=>$travels->pluck('vehicle')->filter()->implode(' | '),
                'distance'=>$travels->sum(fn($r)=>(float)($r['distance']??0)),
                'remarks'=>$data['remarks']??null,'ta'=>$ta,'da'=>$da,'total'=>$ta+$da,
                'status'=>'pending',
                'reviewed_by'=>null,'reviewed_at'=>null,'review_note'=>null,
            ]);

            if (!$activity->exists) {
                $activity->entered_by = $u->id;
            }

            if (!$activity->exists || $u->hasPermissionTo('activity.view_all')) {
                $activity->date = $activityAt->toDateString();
                $activity->activity_at = $activityAt;
            }

            if (!$activity->exists || $this->canManageActivityEntry()) {
                $activity->created_by = $owner->id;
                $activity->branch_id = $owner->branch_id ?? $u->branch_id;
            }

            $activity->save();

            // Keep persisted TA/DA row IDs so each row has its own one-time edit history.
            $existingTravels = $activity->travels()->get()->keyBy('id');
            $submittedTravelIds = collect($travels)->pluck('id')->filter()->map(fn($id)=>(int)$id)->all();
            $keptTravelImages = [];
            foreach ($travels as $r) {
                $travel = !empty($r['id']) ? $existingTravels->get((int)$r['id']) : null;
                if (!empty($r['id']) && !$travel) abort(403, 'Invalid TA entry.');

                $existing = $r['existing_image_url'] ?? null;
                $imagePath = ($existing && in_array($existing, $oldTravelImages, true)) ? $existing : ($travel?->image_url);
                $newImageUploaded = !empty($r['image']);
                if ($newImageUploaded) {
                    $newPath = $this->storeActivityImage($r['image'], 'ta');
                    if ($newPath) $imagePath = $newPath;
                }

                $values = [
                    'note'=>$r['note']??null,'tour_type'=>$activity->tour_type,'from_location'=>$r['from_location']??null,'to_location'=>$r['to_location']??null,'vehicle'=>$r['vehicle']??null,
                    'distance'=>(float)($r['distance']??0),'cost'=>(float)($r['cost']??0),'entry_at'=>
                        \Carbon\Carbon::parse($r['entry_at'],'Asia/Dhaka'),'image_url'=>$imagePath,
                ];

                if ($travel) {
                    if($claimOwnerId!==(int)$u->id && Bills::cents($travel->cost)!==Bills::cents($values['cost'])) throw ValidationException::withMessages(['travels'=>"Use Bill / History to deduct or reject another staff member's TA claim."]);
                    // _edited is set only when the user actually opens this existing TA row and presses Save in the TA modal.
                    // This makes the one-time edit lock deterministic instead of depending only on Eloquent dirty comparison.
                    $attemptedEdit = filter_var($r['_edited'] ?? false, FILTER_VALIDATE_BOOLEAN);
                    if ($attemptedEdit && !$this->canMultipleEdit() && (int)$travel->edit_count >= 1) {
                        throw ValidationException::withMessages(['travels'=>'This TA entry has already been edited once. You cannot edit it again.']);
                    }
                    $travel->fill($values);
                    $changed = $travel->isDirty(['note','from_location','to_location','vehicle','distance','cost','entry_at','image_url']) || $newImageUploaded;
                    if ($attemptedEdit || $changed) {
                        if (!$this->canMultipleEdit() && (int)$travel->edit_count >= 1) {
                            throw ValidationException::withMessages(['travels'=>'This TA entry has already been edited once. You cannot edit it again.']);
                        }
                        $travel->edit_count = ((int)$travel->edit_count) + 1;
                        $travel->last_edited_by = $u->id;
                        $travel->last_edited_at = $now;
                    }
                    $travel->save();
                } else {
                    $travel = $activity->travels()->create($values);
                }
                if ($imagePath) $keptTravelImages[] = $imagePath;
            }
            // Delete ONLY previously persisted TA rows omitted from the form.
            // Never use whereNotIn against the whole relation here: newly-created TA rows
            // do not exist in $submittedTravelIds yet and would be deleted immediately,
            // which caused multiple TA rows to collapse back into the legacy aggregate row.
            $travelIdsToDelete = $existingTravels->keys()->map(fn($id)=>(int)$id)->diff($submittedTravelIds)->values()->all();
            if (!empty($travelIdsToDelete) && $claimOwnerId!==(int)$u->id) throw ValidationException::withMessages(['travels'=>'Use Bill / History to reject an existing staff TA entry instead of deleting it.']);
            if (!empty($travelIdsToDelete)) {
                $activity->travels()->whereIn('id', $travelIdsToDelete)->delete();
            }

            $existingExpenses = $activity->expenses()->get()->keyBy('id');
            $submittedExpenseIds = collect($expenses)->pluck('id')->filter()->map(fn($id)=>(int)$id)->all();
            $keptExpenseImages = [];
            foreach ($expenses as $r) {
                $expense = !empty($r['id']) ? $existingExpenses->get((int)$r['id']) : null;
                if (!empty($r['id']) && !$expense) abort(403, 'Invalid DA entry.');
                $type = !empty($r['expense_type_id']) ? ExpenseType::find($r['expense_type_id']) : null;
                $existing = $r['existing_image_url'] ?? null;
                $imagePath = ($existing && in_array($existing, $oldExpenseImages, true)) ? $existing : ($expense?->image_url);
                $newImageUploaded = !empty($r['image']);
                if ($type?->bill_required && !$newImageUploaded && !$imagePath) {
                    throw ValidationException::withMessages(['expenses'=>'Bill/image is required for '.$type->name.'.']);
                }
                if ($newImageUploaded) {
                    $newPath = $this->storeActivityImage($r['image'], 'da');
                    if ($newPath) $imagePath = $newPath;
                }
                $values = ['expense_type_id'=>$type?->id,'expense_type'=>$type?->name,'amount'=>(float)($r['amount']??0),'note'=>$r['note']??null,
                    'entry_at'=>\Carbon\Carbon::parse($r['entry_at'],'Asia/Dhaka'),'image_url'=>$imagePath];

                if ($expense) {
                    if($claimOwnerId!==(int)$u->id && Bills::cents($expense->amount)!==Bills::cents($values['amount'])) throw ValidationException::withMessages(['expenses'=>"Use Bill / History to deduct or reject another staff member's DA claim."]);
                    // Same one-time edit tracking for each individual DA row.
                    $attemptedEdit = filter_var($r['_edited'] ?? false, FILTER_VALIDATE_BOOLEAN);
                    if ($attemptedEdit && !$this->canMultipleEdit() && (int)$expense->edit_count >= 1) {
                        throw ValidationException::withMessages(['expenses'=>'This DA entry has already been edited once. You cannot edit it again.']);
                    }
                    $expense->fill($values);
                    $changed = $expense->isDirty(['expense_type_id','expense_type','amount','note','entry_at','image_url']) || $newImageUploaded;
                    if ($attemptedEdit || $changed) {
                        if (!$this->canMultipleEdit() && (int)$expense->edit_count >= 1) {
                            throw ValidationException::withMessages(['expenses'=>'This DA entry has already been edited once. You cannot edit it again.']);
                        }
                        $expense->edit_count = ((int)$expense->edit_count) + 1;
                        $expense->last_edited_by = $u->id;
                        $expense->last_edited_at = $now;
                    }
                    $expense->save();
                } else {
                    $expense = $activity->expenses()->create($values);
                }
                if ($imagePath) $keptExpenseImages[] = $imagePath;
            }
            // Same rule for DA: delete only old persisted rows that the user removed.
            // Newly-created DA rows must survive this save so every DA keeps its own ID/edit history.
            $expenseIdsToDelete = $existingExpenses->keys()->map(fn($id)=>(int)$id)->diff($submittedExpenseIds)->values()->all();
            if (!empty($expenseIdsToDelete) && $claimOwnerId!==(int)$u->id) throw ValidationException::withMessages(['expenses'=>'Use Bill / History to reject an existing staff DA entry instead of deleting it.']);
            if (!empty($expenseIdsToDelete)) {
                $activity->expenses()->whereIn('id', $expenseIdsToDelete)->delete();
            }

            foreach (array_diff($oldTravelImages, $keptTravelImages) as $oldImage) $this->deleteActivityImage($oldImage);
            foreach (array_diff($oldExpenseImages, $keptExpenseImages) as $oldImage) $this->deleteActivityImage($oldImage);

            Bills::recalculate($activity,false);
            return $activity->fresh(['travels','expenses','creator']);
        });
    }

    private function bulkQuery(string $source)
    {
        if($source!=='report') return $this->visibleQuery();
        $q=Activity::query();
        if(!auth()->user()->can('report.view_all')) $q->where('created_by',auth()->id())->where('branch_id',auth()->user()->branch_id);
        return $q;
    }

    public function bulkAction(Request $request)
    {
        $data = $request->validate([
            'source'=>'nullable|in:activity,report',
            'ids' => 'required|array|min:1',
            'ids.*' => 'integer',
            'action' => 'required|in:approve,reject,unpaid,waiting_for_payment,paid',
            'review_note' => 'required_if:action,reject|nullable|string|max:2000',
        ]);

        $source=$data['source']??'activity';
        if($source==='report') {
            abort_unless(auth()->user()->can('report.activity.view') && (auth()->user()->can('report.view_all')||auth()->user()->can('report.view_branch')||auth()->user()->can('report.view_self')),403);
        }
        $activities = $this->bulkQuery($source)->whereIn('id', $data['ids'])->get();
        if ($activities->count() !== count(array_unique($data['ids']))) {
            abort(403, 'One or more activities are not accessible.');
        }

        $action = $data['action'];
        $user = Auth::user();
        if (in_array($action, ['approve','reject'], true) && !$user->can('activity.bulk_review')) abort(403);
        if (in_array($action, ['unpaid','waiting_for_payment','paid'], true) && !$user->can('activity.payment.manage')) abort(403);

        $updated = 0;
        $skipped = 0;
        $skipReasons = [];

        DB::transaction(function () use ($activities, $source, $action, $user, $data, &$updated, &$skipped, &$skipReasons) {
            foreach ($activities->sortBy('id') as $listed) {
                $a=$this->bulkQuery($source)->whereKey($listed->id)->lockForUpdate()->firstOrFail();
                if (in_array($action,['approve','reject'],true)) {
                    if($a->status==='rejected' || $a->payment_status==='paid' || ($this->isLocked($a)&&!$this->isSuperAdmin())){ $skipped++; $skipReasons[]="Activity #{$a->id}: paid or locked";continue; }
                    Bills::activityDecision($a,$action==='approve'?'approved':'rejected',$data['review_note']??'');
                } else {
                    // Global safety rule: a rejected activity can NEVER enter payment processing.
                    if (strtolower((string) $a->status) === 'rejected') {
                        $skipped++;
                        $skipReasons[] = "Activity #{$a->id}: rejected";
                        continue;
                    }
                    if(in_array($action,['waiting_for_payment','paid'],true) && (float)$a->total<=0){$skipped++;$skipReasons[]="Activity #{$a->id}: no payable amount";continue;}
                    if ($action === 'waiting_for_payment' && $a->payment_status !== 'unpaid') { $skipped++; continue; }
                    if ($action === 'paid' && $a->payment_status === 'paid') { $skipped++; continue; }
                    if ($action === 'unpaid' && $a->payment_status === 'paid') { $skipped++; continue; }

                    $a->payment_status = $action === 'waiting_for_payment' ? 'waiting_for_payment' : $action;
                    if ($action === 'paid') {
                        $a->paid_at = now('Asia/Dhaka');
                        $a->paid_by = $user->id;
                    } else {
                        $a->paid_at = null;
                        $a->paid_by = null;
                    }
                }
                $a->save();
                $updated++;
            }
        });

        $message = "{$updated} activity(s) updated successfully.";
        if ($skipped > 0) $message .= " {$skipped} activity(s) skipped because they were rejected or not eligible for this transition.";

        return response()->json([
            'status' => true,
            'message' => $message,
            'updated' => $updated,
            'skipped' => $skipped,
            'skip_reasons' => array_values(array_unique($skipReasons)),
        ]);
    }

    public function quickStore(Request $request){ $a=$this->saveActivity(new Activity(),$request); return response()->json(['status'=>true,'message'=>'Field activity created successfully','data'=>$a]); }
    public function store(Request $request){ $this->saveActivity(new Activity(),$request); return response()->json(['status'=>true,'message'=>'Field activity created successfully']); }
    public function organizations(Request $request){
        $term = trim((string)$request->get('q',''));
        $page = max(1,(int)$request->get('page',1));
        $perPage = 20;
        $q = CrmAccess::applyOrganizationScope(Organization::query())->where('status','active');
        if ($term !== '') $q->where(function($x) use($term){
            $x->where('name','like','%'.$term.'%')->orWhere('phone_primary','like','%'.$term.'%')->orWhere('email','like','%'.$term.'%');
        });
        $rows = $q->orderBy('name')->skip(($page-1)*$perPage)->take($perPage+1)->get(['id','name','phone_primary']);
        $more = $rows->count()>$perPage;
        return response()->json(['results'=>$rows->take($perPage)->map(fn($r)=>['id'=>$r->id,'text'=>$r->name.($r->phone_primary?' · '.$r->phone_primary:'')])->values(),'pagination'=>['more'=>$more]]);
    }
    public function departments(){ return response()->json(Department::select('id','title')->orderBy('title')->get()); }
    public function show($id){
        $activity=$this->findVisible((int)$id);
        if($activity->payment_status==='paid'||Bills::hasHistory($activity)) return redirect()->route('activities.bill-review',$activity->id);
        $this->ensureUnlockedOrSuperAdmin($activity, 'edit');
        return view('backend.content.activity.edit',[
            'activity'=>$activity,
            'isAdmin'=>$this->isAdmin(),
            'canManageActivityEntry'=>$this->canManageActivityEntry(),
            'staffs'=>$this->manageableStaffs(),
            'expenseTypes'=>ExpenseType::where('status',1)->orderBy('sort_order')->orderBy('name')->get(),
        ]);
    }
    public function update(Request $request,$id){ $a=$this->saveActivity($this->findVisible((int)$id),$request); return response()->json(['status'=>true,'message'=>'Field activity updated successfully','data'=>$a]); }
    public function review(Request $request, $id)
    {
        $data = $request->validate(['status'=>'required|in:approved,rejected','review_note'=>'required_if:status,rejected|nullable|string|max:2000']);
        DB::transaction(function()use($id,$data){
            $activity=$this->visibleQuery()->whereKey($id)->lockForUpdate()->firstOrFail();
            $this->ensureUnlockedOrSuperAdmin($activity,'review');
            Bills::activityDecision($activity,$data['status'],$data['review_note']??'');
        });
        return response()->json(['status'=>true,'message'=>'Activity '.($data['status']==='approved'?'approved':'rejected').' successfully']);
    }

    public function destroy($id){
        $images=DB::transaction(function()use($id){
            $activity=$this->visibleQuery()->whereKey($id)->lockForUpdate()->firstOrFail();
            $this->ensureUnlockedOrSuperAdmin($activity,'delete');
            if($activity->payment_status==='paid'||Bills::hasHistory($activity)) throw ValidationException::withMessages(['activity'=>'Reviewed or paid activity history must be retained.']);
            $images=$activity->travels->pluck('image_url')->merge($activity->expenses->pluck('image_url'))->filter()->values();
            $activity->delete();return $images;
        });
        $images->each(fn($path) => $this->deleteActivityImage($path));
        return response()->json(['status'=>true,'message'=>'Deleted']);
    }
}
