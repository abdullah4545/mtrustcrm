<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('leads', function (Blueprint $table) {
            $table->text('existing_machine')->nullable()->change();
        });
    }
    public function down(): void {
        Schema::table('leads', function (Blueprint $table) {
            $table->string('existing_machine', 255)->nullable()->change();
        });
    }
};
