@extends('backend.master')

@section('title')
{{ ($business?->business_name ?? 'Medi Trust Solution') }} - Activities
@endsection

@section('maincontent') 

    <div class="nxl-content"> 
        {{-- HEADER --}}
        <div class="page-header d-flex justify-content-between align-items-center">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10">Activity</h5>
                </div>

                <div class="d-none d-lg-block">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                        <li class="breadcrumb-item">Activity</li>
                    </ul>
                </div>
            </div>

            <a href="{{route('activities.quick.create')}}" class="btn btn-primary">
                <i class="feather-plus"></i> Add Activity
            </a>
        </div>

    </div>

    <div class="main-content">
        <div class="card">
            <div class="card-body">
                <div class="row g-2 mb-3">
                    @if($showStaffColumn && auth()->user()->can('staff.filter'))
                    <div class="col-md-3">
                        <label class="form-label">Staff / Created By</label>
                        <select id="f_created_by" class="form-control">
                            <option value="">All Staff</option>
                            @foreach($staffs as $staff)
                                <option value="{{ $staff->id }}">{{ $staff->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    @endif
                    <div class="col-md-3">
                        <label class="form-label">From Date</label>
                        <input type="date" id="f_from_date" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">To Date</label>
                        <input type="date" id="f_to_date" class="form-control">
                    </div>
                    @if($showStatus)
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select id="f_status" class="form-control">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                    @endif
                    <div class="col-md-3"><label class="form-label">Payment Status</label><select id="f_payment_status" class="form-control"><option value="">All Payment Status</option><option value="unpaid">Unpaid</option><option value="waiting_for_payment">Waiting for Payment</option><option value="paid">Paid</option></select></div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="button" id="f_date_reset" class="btn btn-light w-100">Reset Date</button>
                    </div>
                </div>

                @if($canBulkReview || $canManagePayment)<div class="d-flex flex-wrap gap-2 mb-3 align-items-center"><strong>Bulk Action:</strong>@if($canBulkReview)<button class="btn btn-sm btn-success bulk-action" data-action="approve">Approve</button><button class="btn btn-sm btn-danger bulk-action" data-action="reject">Reject</button>@endif @if($canManagePayment)<button class="btn btn-sm btn-secondary bulk-action" data-action="unpaid">Mark Unpaid</button><button class="btn btn-sm btn-warning bulk-action" data-action="waiting_for_payment">Waiting for Payment</button><button class="btn btn-sm btn-primary bulk-action" data-action="paid">Mark Paid</button>@endif <span id="selectedCount" class="text-muted small">0 selected</span></div>@endif

                <table class="table table-bordered" id="activityTable">
                    <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" class="form-check-input"></th>
                        <th>#</th>
                        <th>Date</th>
                        @if($showStaffColumn)<th>Staff</th>@endif
                        <th>Organization / Contact</th>
                        <th>From</th>
                        <th>To</th>
                        <th>TA</th>
                        <th>DA</th>
                        <th>Total</th>
                        <th>Tour Type</th>
                        <th>Payment Status</th>
                        @if($showStatus)<th>Status</th>@endif
                        @if($showEditAudit)<th>Edit History</th>@endif
                        <th width="150">Action</th>
                    </tr>
                    </thead>
                </table>

            </div>
        </div>
    </div>

@endsection


@push('modals')
<div class="modal fade" id="activityModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 id="modalTitle">Add Activity</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <form id="activityForm" method="POST">
                    @csrf
                    <input type="hidden" id="activity_id">

                    <div class="row g-2">

                        <div class="col-md-3">
                            <label>Date</label>
                            <input type="date" id="date" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label>Organization</label>
                            <select id="organization_id" class="form-control" required>
                                <option value="">Select Organization</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label>Department</label>
                            <select id="department" class="form-control">
                                <option value="">Select Department</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label>Contact Person</label>
                            <input type="text" id="contact_person" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label>From</label>
                            <input type="text" id="from_location" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label>To</label>
                            <input type="text" id="to_location" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label>Vehicle</label>
                            <input type="text" id="vehicle" class="form-control">
                        </div>

                        <div class="col-md-12">
                            <label>Work Details</label>
                            <textarea id="work_details" class="form-control"></textarea>
                        </div>

                        <div class="col-md-3">
                            <label>TA</label>
                            <input type="number" id="ta" class="form-control" value="0">
                        </div>

                        <div class="col-md-3">
                            <label>DA</label>
                            <input type="number" id="da" class="form-control" value="0">
                        </div>

                        <div class="col-md-3">
                            <label>Total</label>
                            <input type="number" id="total" class="form-control" readonly>
                        </div>

                        <div class="col-md-12">
                            <label>Remarks</label>
                            <textarea id="remarks" class="form-control"></textarea>
                        </div>

                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" id="btnSave">Save</button>
            </div>

        </div>
    </div>
</div>
@endpush

@push('scripts')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    let table, modal;

    const ROUTE_DATATABLE = "{{ route('activities.datatable') }}";
    const ROUTE_STORE = "{{ route('activities.store') }}";
    const ROUTE_UPDATE = "{{ url('activities') }}";
    const ROUTE_DELETE = "{{ url('activities') }}";
    const ROUTE_ORG = "{{ url('activities/ajax/organizations') }}";
    const ROUTE_DEP = "{{ url('activities/ajax/departments') }}";

    function loadDropdowns(){
        if($.fn.select2){
            $('#organization_id').select2({width:'100%',placeholder:'Search organization...',dropdownParent:$('#organization_id').closest('.modal').length?$('#organization_id').closest('.modal').find('.modal-content').first():$(document.body),ajax:{url:ROUTE_ORG,dataType:'json',delay:300,data:p=>({q:p.term||'',page:p.page||1}),processResults:r=>r,cache:true}});
        }

        // department
        $.get(ROUTE_DEP, function(res){
            let html = `<option value="">Select Department</option>`;
            res.forEach(v=>{
                html += `<option value="${v.title}">${v.title}</option>`;
            });
            $('#department').html(html);
        });
    }

    $(document).ready(function(){

   

        table = $('#activityTable').DataTable({
            processing:true,
            serverSide:true,
            ajax:{url:ROUTE_DATATABLE,data:function(d){d.created_by=$('#f_created_by').val();d.from_date=$('#f_from_date').val();d.to_date=$('#f_to_date').val();d.status=@json($showStatus) ? $('#f_status').val() : '';d.payment_status=$('#f_payment_status').val();}},
            columns:[
                {data:'select',orderable:false,searchable:false},
                {data:'DT_RowIndex', orderable:false, searchable:false},
                {data:'date'},
                @if($showStaffColumn)
                {data:'staff_name', orderable:false, searchable:false},
                @endif
                {data:'organization_contact', name:'organization_name'},
                {data:'from_location'},
                {data:'to_location'},
                {data:'ta'},
                {data:'da'},
                {data:'total'},
                {data:'tour_type',orderable:false,searchable:false},
                {data:'payment_status',orderable:false,searchable:false},
                @if($showStatus)
                {data:'status'},
                @endif
                @if($showEditAudit)
                {data:'edit_history', orderable:false, searchable:false},
                @endif
                {data:'action', orderable:false, searchable:false},
            ]
        });

        

        $('#f_created_by,#f_from_date,#f_to_date,@if($showStatus)#f_status,@endif #f_payment_status').on('change',function(){table.ajax.reload();});
        $('#f_date_reset').on('click',function(){$('#f_from_date,#f_to_date,#f_payment_status@if($showStatus),#f_status@endif').val('');table.ajax.reload();});

        $('#ta,#da').on('keyup change', function(){
            let ta = parseFloat($('#ta').val()) || 0;
            let da = parseFloat($('#da').val()) || 0;
            $('#total').val(ta + da);
        });
  

        $(document).on('click','.btn-delete',function(){
            let id = $(this).data('id');

            if(confirm('Delete?')){
                $.post(ROUTE_DELETE+'/'+id+'/delete',{},function(){
                    table.ajax.reload();
                });
            }
        });


        function updateSelected(){ $('#selectedCount').text($('.activity-check:checked').length+' selected'); }
        $('#selectAll').on('change',function(){ $('.activity-check').prop('checked',this.checked); updateSelected(); });
        $(document).on('change','.activity-check',updateSelected);
        table.on('draw',function(){ $('#selectAll').prop('checked',false); updateSelected(); });
        $(document).on('click','.bulk-action',function(){
            const ids=$('.activity-check:checked').map(function(){return Number(this.value)}).get(), action=$(this).data('action');
            if(!ids.length){Swal.fire('Select Activity','Please select at least one activity.','warning');return;}
            Swal.fire({title:'Apply bulk action?',text:`${ids.length} activity(s): ${String(action).replaceAll('_',' ')}`,icon:'question',showCancelButton:true,confirmButtonText:'Yes, continue'}).then(r=>{if(!r.isConfirmed)return; $.post(@json(route('activities.bulk-action')),{ids,action}).done(x=>{Swal.fire('Done',x.message,'success');table.ajax.reload(null,false)}).fail(x=>{let m=x.responseJSON?.message||'Unable to update';if(x.status===422&&x.responseJSON?.errors)m=Object.values(x.responseJSON.errors)[0][0];Swal.fire('Blocked',m,'error')});});
        });

        $(document).on('click','.btn-review',function(){
            const id=$(this).data('id'), status=$(this).data('status');
            Swal.fire({title:status==='approved'?'Approve activity?':'Reject activity?',input:'text',inputLabel:'Review note (optional)',showCancelButton:true,confirmButtonText:status==='approved'?'Approve':'Reject'}).then(r=>{
                if(!r.isConfirmed) return;
                $.post(ROUTE_UPDATE+'/'+id+'/review',{status:status,review_note:r.value||''}).done(x=>{Swal.fire('Done',x.message,'success');table.ajax.reload(null,false)}).fail(x=>Swal.fire('Error',x.responseJSON?.message||'Unable to review','error'));
            });
        });

    });

    function clearForm(){
        $('#activityForm')[0].reset();
        $('#activity_id').val('');
        $('#total').val(0);
    }
</script>
@endpush