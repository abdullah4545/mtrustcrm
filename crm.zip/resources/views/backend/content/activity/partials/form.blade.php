@php
    $editing = isset($activity) && $activity;
    $activityTime = $editing ? ($activity->activity_at ?? $activity->created_at) : now('Asia/Dhaka');
    $travelRows = $editing && $activity->travels->count()
        ? $activity->travels
        : ($editing && ($activity->from_location || $activity->to_location || (float)$activity->ta > 0)
            ? collect([(object)[
                'from_location'=>$activity->from_location,
                'to_location'=>$activity->to_location,
                'vehicle'=>$activity->vehicle,
                'distance'=>$activity->distance,
                'cost'=>$activity->ta,
            ]])
            : collect());
    $expenseRows = $editing && $activity->expenses->count() ? $activity->expenses : collect();
    $canManageActivityEntry = $canManageActivityEntry ?? false;
    $canMultipleTaDaEdit = auth()->user()?->hasPermissionTo('activity.multiple_edit') ?? false;

    $initialTravels = $travelRows->map(function ($row) use ($activityTime) {
        $entryAt = data_get($row, 'entry_at');
        $imageUrl = (string) data_get($row, 'image_url', '');

        return [
            'id' => data_get($row, 'id'),
            'edit_count' => (int) data_get($row, 'edit_count', 0),
            '_edited' => false,
            'last_edited_by_name' => (string) data_get($row, 'lastEditor.name', ''),
            'last_edited_at' => data_get($row, 'last_edited_at')
                ? \Illuminate\Support\Carbon::parse(data_get($row, 'last_edited_at'))->timezone('Asia/Dhaka')->format('d M Y, h:i A')
                : '',
            'tour_type' => (string) data_get($row, 'tour_type', 'local_tour'),
            'from_location' => (string) data_get($row, 'from_location', ''),
            'to_location' => (string) data_get($row, 'to_location', ''),
            'vehicle' => (string) data_get($row, 'vehicle', ''),
            'distance' => (float) data_get($row, 'distance', 0),
            'cost' => (float) data_get($row, 'cost', 0),
            'entry_at' => $entryAt
                ? \Illuminate\Support\Carbon::parse($entryAt)->timezone('Asia/Dhaka')->format('Y-m-d\TH:i')
                : '',
            'image_url' => $imageUrl,
            'image_view_url' => $imageUrl !== '' ? asset($imageUrl) : '',
        ];
    })->values();

    $initialExpenses = $expenseRows->map(function ($row) use ($activityTime) {
        $entryAt = data_get($row, 'entry_at');
        $imageUrl = (string) data_get($row, 'image_url', '');

        return [
            'id' => data_get($row, 'id'),
            'edit_count' => (int) data_get($row, 'edit_count', 0),
            '_edited' => false,
            'last_edited_by_name' => (string) data_get($row, 'lastEditor.name', ''),
            'last_edited_at' => data_get($row, 'last_edited_at')
                ? \Illuminate\Support\Carbon::parse(data_get($row, 'last_edited_at'))->timezone('Asia/Dhaka')->format('d M Y, h:i A')
                : '',
            'expense_type_id' => (string) data_get($row, 'expense_type_id', ''),
            'expense_type' => (string) data_get($row, 'expense_type', ''),
            'amount' => (float) data_get($row, 'amount', 0),
            'note' => (string) data_get($row, 'note', ''),
            'entry_at' => $entryAt
                ? \Illuminate\Support\Carbon::parse($entryAt)->timezone('Asia/Dhaka')->format('Y-m-d\TH:i')
                : '',
            'image_url' => $imageUrl,
            'image_view_url' => $imageUrl !== '' ? asset($imageUrl) : '',
        ];
    })->values();
@endphp

<style>
.activity-entry-card{border:0;border-radius:18px;box-shadow:0 10px 30px rgba(15,23,42,.07)}
.activity-entry-card label{font-weight:600;margin-bottom:6px;display:inline-flex;align-items:center;gap:3px;line-height:1.25}.required-mark{color:#dc3545!important;font-weight:700;display:inline!important;line-height:1!important;vertical-align:baseline!important}
.activity-section{border:1px solid #e8edf3;border-radius:16px;background:#fff;overflow:hidden}
.activity-section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;border-bottom:1px solid #eef2f6;background:#fafbfc}
.activity-section-body{padding:12px}
.activity-empty{padding:24px 12px;text-align:center;color:#98a2b3;border:1px dashed #dbe2ea;border-radius:12px;background:#fbfcfd}
.activity-list-item{display:flex;gap:12px;align-items:center;padding:12px;border:1px solid #edf1f5;border-radius:13px;background:#fff;margin-bottom:10px}
.activity-list-item:last-child{margin-bottom:0}
.activity-list-main{min-width:0;flex:1}
.activity-list-title{font-weight:700;color:#1f2937;word-break:break-word}
.activity-list-meta{display:flex;flex-wrap:wrap;gap:6px 12px;margin-top:4px;color:#667085;font-size:12px}
.activity-list-amount{font-weight:700;white-space:nowrap;color:#111827}
.activity-list-actions{display:flex;gap:6px;flex:0 0 auto}
.icon-action{width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;border-radius:9px;padding:0}
.summary-box{background:#f8fafc;border-radius:14px;padding:16px}
.activity-entry-card .select2-container{width:100%!important}.activity-entry-card .select2-container .select2-selection--single{min-height:42px!important;height:42px!important;display:flex!important;align-items:center!important;border:1px solid #ced4da!important;border-radius:.375rem!important}.activity-entry-card .select2-container--default .select2-selection--single .select2-selection__rendered{width:100%!important;line-height:normal!important;padding-left:12px!important;padding-right:38px!important;margin:0!important}.activity-entry-card .select2-container--default .select2-selection--single .select2-selection__arrow{height:40px!important;top:0!important;right:6px!important}
.modal-backdrop{z-index:1050!important;backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);background-color:rgba(15,23,42,.38)!important}
.modal-backdrop.show{opacity:1!important}
.activity-modal{z-index:1060!important;filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.activity-modal .modal-dialog{position:relative;z-index:1061;filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.activity-modal .modal-content{position:relative;z-index:1062;border:0;border-radius:18px;background:#fff!important;opacity:1!important;filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;box-shadow:0 18px 50px rgba(15,23,42,.2)}
.activity-modal .modal-header{border-bottom:1px solid #eef2f6}.activity-modal .modal-footer{border-top:1px solid #eef2f6}
.mobile-add-btn{white-space:nowrap}
@media(max-width:767.98px){
    .nxl-content .main-content{padding-left:12px!important;padding-right:12px!important}
    .activity-entry-card .card-body{padding:12px}
    .activity-entry-card .row.g-3{--bs-gutter-x:.75rem;--bs-gutter-y:.75rem}
    .activity-section-head{padding:12px;align-items:flex-start}
    .activity-section-head small{font-size:11px;line-height:1.4;display:block;padding-right:4px}
    .activity-section-body{padding:10px}
    .activity-list-item{align-items:flex-start;gap:8px;padding:10px}
    .activity-list-amount{font-size:13px}
    .activity-list-actions{gap:4px}
    .icon-action{width:32px;height:32px}
    .mobile-add-btn{padding:.45rem .6rem;font-size:12px}
    .summary-box{padding:12px 6px}
    .summary-box h5{font-size:16px}
    .activity-save{width:100%;padding:.7rem 1rem}
    .activity-modal .modal-dialog{margin:8px}
    .activity-modal .modal-content{border-radius:15px}
    .activity-modal .modal-body{padding:14px}
    .activity-modal .modal-footer{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:12px}
    .activity-modal .modal-footer .btn{margin:0;width:100%}
}
@media(max-width:420px){
    .activity-section-head{gap:8px}
    .activity-section-head h6{font-size:14px}
    .activity-list-item{display:grid;grid-template-columns:minmax(0,1fr) auto}
    .activity-list-main{grid-column:1/2}
    .activity-list-amount{grid-column:2/3;grid-row:1}
    .activity-list-actions{grid-column:1/3;justify-content:flex-end;margin-top:2px}
}
</style>

<div class="card activity-entry-card"><div class="card-body">
<form id="activityForm">
<div class="row g-3">
    @if($canManageActivityEntry)
    <div class="col-6 col-md-2"><label>Activity Date</label><input type="date" id="activity_date" class="form-control" value="{{ $activityTime?->timezone('Asia/Dhaka')->format('Y-m-d') }}" required></div>
    <div class="col-6 col-md-2"><label>Activity Time</label><input type="time" id="activity_time" class="form-control" value="{{ $activityTime?->timezone('Asia/Dhaka')->format('H:i') }}" required></div>
    @else
    <div class="col-12 col-md-4"><label>Activity Date & Time</label><input class="form-control" value="{{ $activityTime?->timezone('Asia/Dhaka')->format('d M Y, h:i A') }}" readonly></div>
    @endif

    @if($canManageActivityEntry)
    <div class="col-12 col-md-4">
        <label>Staff</label>
        <select id="staff_id" class="form-control">
            <option value="">Myself</option>
            @foreach($staffs as $staff)
                <option value="{{ $staff->id }}" {{ $editing && (int)$activity->created_by === (int)$staff->id ? 'selected' : '' }}>{{ $staff->name }}</option>
            @endforeach
        </select>
    </div>
    @endif

    <div class="col-12 col-md-4"><label>Organization <span class="text-muted">(Optional)</span></label><select id="organization_id" class="form-control"><option value="">Select Organization</option></select></div>
    <div class="col-12 col-md-4"><label>Department <span class="text-muted">(Optional)</span></label><select id="department" class="form-control"><option value="">Select Department</option></select></div>
    <div class="col-12 col-md-4"><label>Contact Person</label><input type="text" id="contact_person" class="form-control" value="{{ $editing ? $activity->contact_person : '' }}" placeholder="Type contact person name"></div>

    <div class="col-12">
        <div class="activity-section">
            <div class="activity-section-head">
                <div><h6 class="mb-0">TA / Travel</h6></div>
                <button type="button" class="btn btn-sm btn-primary mobile-add-btn" id="addTravel"><i class="feather-plus me-1"></i>Add Travel</button>
            </div>
            <div class="activity-section-body" id="travelList"></div>
        </div>
    </div>

    <div class="col-12">
        <div class="activity-section">
            <div class="activity-section-head">
                <div><h6 class="mb-0">DA / Other Cost</h6></div>
                <button type="button" class="btn btn-sm btn-primary mobile-add-btn" id="addExpense"><i class="feather-plus me-1"></i>Add Cost</button>
            </div>
            <div class="activity-section-body" id="expenseList"></div>
        </div>
    </div>

    <div class="col-12"><label>Visit Output *</label><textarea id="work_details" class="form-control" rows="4" required>{{ $editing?$activity->work_details:'' }}</textarea></div>
    <div class="col-12"><label>Remarks</label><textarea id="remarks" class="form-control" rows="3">{{ $editing?$activity->remarks:'' }}</textarea></div>

    <div class="col-12"><div class="summary-box row g-2 text-center"><div class="col-4"><small>Total TA</small><h5 class="mb-0" id="taText">0.00</h5></div><div class="col-4"><small>Total DA</small><h5 class="mb-0" id="daText">0.00</h5></div><div class="col-4"><small>Grand Total</small><h5 class="mb-0" id="totalText">0.00</h5></div></div></div>
    <div class="col-12 text-end"><button type="button" class="btn btn-primary activity-save" id="btnSave">{{ $editing?'Update Activity':'Save Activity' }}</button></div>
</div>
</form>
</div></div>

<div class="modal fade activity-modal" id="travelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="travelModalTitle">Add Travel</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body">
                <input type="hidden" id="travelEditIndex" value="">
                <div class="row g-3">
                    <div class="col-6"><label>TA Date *</label><input type="date" id="travel_date" class="form-control" required></div>
                    <div class="col-6"><label>TA Time *</label><input type="time" id="travel_time" class="form-control" required></div>
                    <div class="col-12"><label>Tour Type</label><select id="travel_tour_type" class="form-control"><option value="local_tour">Local Tour</option><option value="tour">Tour</option></select></div>
                    <div class="col-12"><label>From *</label><input id="travel_from" class="form-control" required placeholder="From location"></div>
                    <div class="col-12"><label>To *</label><input id="travel_to" class="form-control" required placeholder="To location"></div>
                    <div class="col-12 col-sm-6"><label>Vehicle</label><select id="travel_vehicle" class="form-control"><option value="">Select Vehicle</option></select></div>
                    <div class="col-6 col-sm-3"><label>Distance (KM) <span class="required-mark">*</span></label><input type="number" min="0" step="0.01" id="travel_distance" class="form-control" value="0" required></div>
                    <div class="col-6 col-sm-3"><label>Cost</label><input type="number" min="0" step="0.01" id="travel_cost" class="form-control" value="0"></div>
                    <div class="col-12"><label>TA Image</label><input type="file" accept="image/*" id="travel_image" class="form-control"><small class="text-muted" id="travel_image_hint">JPG, PNG or WEBP - max 5 MB.</small><div id="travel_current_image" class="mt-2"></div></div>
                </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="saveTravelRow">Save Travel</button></div>
        </div>
    </div>
</div>

<div class="modal fade activity-modal" id="expenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="expenseModalTitle">Add Cost</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body">
                <input type="hidden" id="expenseEditIndex" value="">
                <div class="row g-3">
                    <div class="col-6"><label>DA Date *</label><input type="date" id="expense_date" class="form-control" required></div>
                    <div class="col-6"><label>DA Time *</label><input type="time" id="expense_time" class="form-control" required></div>
                    <div class="col-12"><label>Expense Type *</label><select id="expense_type" class="form-control" required><option value="">Select Type</option>@foreach($expenseTypes as $type)<option value="{{ $type->id }}" data-name="{{ $type->name }}" data-bill-required="{{ $type->bill_required ? 1 : 0 }}">{{ $type->name }}</option>@endforeach</select></div>
                    <div class="col-12"><label>Amount</label><input type="number" min="0" step="0.01" id="expense_amount" class="form-control" value="0"></div>
                    <div class="col-12"><label>Note</label><input id="expense_note" class="form-control" placeholder="Optional note"></div>
                    <div class="col-12"><label>DA / Cost Image</label><input type="file" accept="image/*" id="expense_image" class="form-control"><small class="text-muted" id="expense_image_hint">JPG, PNG or WEBP - max 5 MB.</small><div id="expense_current_image" class="mt-2"></div></div>
                </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="saveExpenseRow">Save Cost</button></div>
        </div>
    </div>
</div>

@push('scripts')
<script>
$.ajaxSetup({headers:{'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')}});

const ACTIVITY_URL = @json($editing ? route('activities.update',$activity->id) : route('activities.quick.store'));
const ORG_URL = @json(url('activities/ajax/organizations'));
const VEHICLE_URL = @json(url('activities/ajax/vehicles'));
const DEPT_URL = @json(url('activities/ajax/departments'));
const CONTACT_URL = @json(url('activities/ajax/org-contacts'));
const OLD_ORG = @json($editing ? (string)$activity->organization_id : '');
const OLD_DEPT = @json($editing ? (string)$activity->department_id : '');
const OLD_CONTACT = @json($editing ? (string)$activity->contact_id : '');
const CAN_MANAGE_ENTRY = @json((bool)$canManageActivityEntry);
const CAN_MULTIPLE_TADA_EDIT = @json((bool)$canMultipleTaDaEdit);
let travels = @json($initialTravels);
let expenses = @json($initialExpenses);
let vehicles = [];
let travelModal, expenseModal;

function esc(v){ return $('<div>').text(v ?? '').html(); }
function money(v){ return (parseFloat(v)||0).toFixed(2); }
function nowParts(){ const d=new Date(); const pad=n=>String(n).padStart(2,'0'); return {date:d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()),time:pad(d.getHours())+':'+pad(d.getMinutes())}; }
function entryParts(v){ if(!v) return {date:nowParts().date,time:''}; const a=String(v).replace(' ','T').split('T'); return {date:a[0]||nowParts().date,time:(a[1]||'').slice(0,5)}; }
function displayEntry(v){ if(!v) return ''; const p=entryParts(v); const d=new Date(p.date+'T'+p.time); return isNaN(d)?'':d.toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true}); }

function recalc(){
    const ta = travels.reduce((s,r)=>s+(parseFloat(r.cost)||0),0);
    const da = expenses.reduce((s,r)=>s+(parseFloat(r.amount)||0),0);
    $('#taText').text(ta.toFixed(2));
    $('#daText').text(da.toFixed(2));
    $('#totalText').text((ta+da).toFixed(2));
}

function renderTravels(){
    const box = $('#travelList');
    if(!travels.length){
        box.html('<div class="activity-empty"><i class="feather-navigation d-block mb-2" style="font-size:22px"></i>No travel added yet.</div>');
        recalc(); return;
    }
    let html='';
    travels.forEach((r,i)=>{
        html += `<div class="activity-list-item">
            <div class="activity-list-main">
                <div class="activity-list-title">${esc(r.from_location || '—')} <i class="feather-arrow-right mx-1"></i> ${esc(r.to_location || '—')}</div>
                <div class="activity-list-meta">
                    <span><i class="feather-tag me-1"></i>${r.tour_type==='tour'?'Tour':'Local Tour'}</span><span><i class="feather-truck me-1"></i>${esc(r.vehicle || 'No vehicle')}</span>
                    <span><i class="feather-map-pin me-1"></i>${money(r.distance)} KM</span>
                    <span><i class="feather-calendar me-1"></i>${esc(displayEntry(r.entry_at))}</span>
                </div>
            </div>
            <div class="activity-list-amount">৳${money(r.cost)}</div>
            <div class="activity-list-actions">
                ${(r.image_preview_url || r.image_view_url) ? `<a href="${esc(r.image_preview_url || r.image_view_url)}" data-crm-image="true" class="btn btn-outline-success icon-action" title="View Image"><i class="feather-image"></i></a>` : ''}
                ${(!r.id || CAN_MULTIPLE_TADA_EDIT || Number(r.edit_count||0) < 1) ? `<button type="button" class="btn btn-outline-primary icon-action edit-travel" data-index="${i}" title="Edit"><i class="feather-edit-2"></i></button>` : `<span class="badge bg-light text-dark align-self-center">Edited</span>`}
                ${CAN_MULTIPLE_TADA_EDIT && r.id ? `<span class="badge bg-info-subtle text-info align-self-center" title="${esc(r.last_edited_by_name||'')}${r.last_edited_at ? ' · '+esc(r.last_edited_at) : ''}">${Number(r.edit_count||0)>0 ? 'Edited '+Number(r.edit_count||0)+'x' : 'Not Edited'}</span>` : ''}
                <button type="button" class="btn btn-outline-danger icon-action delete-travel" data-index="${i}" title="Delete"><i class="feather-trash-2"></i></button>
            </div>
        </div>`;
    });
    box.html(html); recalc();
}

function renderExpenses(){
    const box = $('#expenseList');
    if(!expenses.length){
        box.html('<div class="activity-empty"><i class="feather-credit-card d-block mb-2" style="font-size:22px"></i>No other cost added yet.</div>');
        recalc(); return;
    }
    let html='';
    expenses.forEach((r,i)=>{
        html += `<div class="activity-list-item">
            <div class="activity-list-main">
                <div class="activity-list-title">${esc(r.expense_type || 'Other Cost')}</div>
                <div class="activity-list-meta"><span><i class="feather-calendar me-1"></i>${esc(displayEntry(r.entry_at))}</span>${r.note ? `<span><i class="feather-file-text me-1"></i>${esc(r.note)}</span>` : '<span>No note</span>'}</div>
            </div>
            <div class="activity-list-amount">৳${money(r.amount)}</div>
            <div class="activity-list-actions">
                ${(r.image_preview_url || r.image_view_url) ? `<a href="${esc(r.image_preview_url || r.image_view_url)}" data-crm-image="true" class="btn btn-outline-success icon-action" title="View Image"><i class="feather-image"></i></a>` : ''}
                ${(!r.id || CAN_MULTIPLE_TADA_EDIT || Number(r.edit_count||0) < 1) ? `<button type="button" class="btn btn-outline-primary icon-action edit-expense" data-index="${i}" title="Edit"><i class="feather-edit-2"></i></button>` : `<span class="badge bg-light text-dark align-self-center">Edited</span>`}
                ${CAN_MULTIPLE_TADA_EDIT && r.id ? `<span class="badge bg-info-subtle text-info align-self-center" title="${esc(r.last_edited_by_name||'')}${r.last_edited_at ? ' · '+esc(r.last_edited_at) : ''}">${Number(r.edit_count||0)>0 ? 'Edited '+Number(r.edit_count||0)+'x' : 'Not Edited'}</span>` : ''}
                <button type="button" class="btn btn-outline-danger icon-action delete-expense" data-index="${i}" title="Delete"><i class="feather-trash-2"></i></button>
            </div>
        </div>`;
    });
    box.html(html); recalc();
}

function fillVehicleOptions(selected=''){
    let html='<option value="">Select Vehicle</option>';
    vehicles.forEach(v=>{ html += `<option value="${esc(v.title)}" ${v.title===selected?'selected':''}>${esc(v.title)}</option>`; });
    $('#travel_vehicle').html(html);
}

function resetTravelModal(){
    $('#travelEditIndex').val(''); $('#travelModalTitle').text('Add Travel');
    $('#travel_from,#travel_to').val(''); $('#travel_tour_type').val('local_tour'); const np=nowParts(); $('#travel_date').val(np.date); $('#travel_time').val(''); $('#travel_distance,#travel_cost').val(0); $('#travel_image').val(''); $('#travel_image_hint').text('JPG, PNG or WEBP - max 5 MB.'); $('#travel_current_image').empty(); fillVehicleOptions('');
}
function openTravelEdit(index){
    const r=travels[index]; if(!r) return;
    if(r.id && !CAN_MULTIPLE_TADA_EDIT && Number(r.edit_count||0) >= 1){ Swal.fire('Edit Locked','This TA has already been edited once.','info'); return; }
    $('#travelEditIndex').val(index); $('#travelModalTitle').text('Edit Travel');
    const ep=entryParts(r.entry_at); $('#travel_date').val(ep.date); $('#travel_time').val(ep.time); $('#travel_tour_type').val(r.tour_type||'local_tour'); $('#travel_from').val(r.from_location); $('#travel_to').val(r.to_location); fillVehicleOptions(r.vehicle); $('#travel_distance').val(r.distance); $('#travel_cost').val(r.cost); $('#travel_image').val('');
    $('#travel_image_hint').text((r.image_file?.name || (r.image_url ? 'Current image attached. Choose a file only to replace it.' : 'JPG, PNG or WEBP - max 5 MB.')));
    const travelImg = r.image_preview_url || r.image_view_url || '';
    $('#travel_current_image').html(travelImg ? `<a href="${esc(travelImg)}" data-crm-image="true" class="d-inline-flex align-items-center gap-2"><img src="${esc(travelImg)}" alt="TA attachment" style="width:72px;height:72px;object-fit:cover;border:1px solid #ddd;border-radius:8px"><span>Open current image</span></a>` : '');
    travelModal.show();
}

function resetExpenseModal(){
    $('#expenseEditIndex').val(''); $('#expenseModalTitle').text('Add Cost');
    const np=nowParts(); $('#expense_date').val(np.date); $('#expense_time').val(''); $('#expense_type').val(''); $('#expense_amount').val(0); $('#expense_note').val(''); $('#expense_image').val(''); $('#expense_image_hint').text('JPG, PNG or WEBP - max 5 MB.'); $('#expense_current_image').empty();
}
function openExpenseEdit(index){
    const r=expenses[index]; if(!r) return;
    if(r.id && !CAN_MULTIPLE_TADA_EDIT && Number(r.edit_count||0) >= 1){ Swal.fire('Edit Locked','This DA has already been edited once.','info'); return; }
    $('#expenseEditIndex').val(index); $('#expenseModalTitle').text('Edit Cost');
    const ep=entryParts(r.entry_at); $('#expense_date').val(ep.date); $('#expense_time').val(ep.time);
    const expenseTypeId=String(r.expense_type_id||'');
    $('#expense_type').val(expenseTypeId).trigger('change.select2');
    // Fallback for old DA rows where only the expense type name was saved.
    if(!$('#expense_type').val() && r.expense_type){
        $('#expense_type option').filter(function(){ return $.trim($(this).text()).toLowerCase() === $.trim(String(r.expense_type)).toLowerCase(); }).first().prop('selected',true);
        $('#expense_type').trigger('change.select2');
    }
    $('#expense_amount').val(r.amount); $('#expense_note').val(r.note||''); $('#expense_image').val('');
    $('#expense_image_hint').text((r.image_file?.name || (r.image_url ? 'Current image attached. Choose a file only to replace it.' : 'JPG, PNG or WEBP - max 5 MB.')));
    const expenseImg = r.image_preview_url || r.image_view_url || '';
    $('#expense_current_image').html(expenseImg ? `<a href="${esc(expenseImg)}" data-crm-image="true" class="d-inline-flex align-items-center gap-2"><img src="${esc(expenseImg)}" alt="DA attachment" style="width:72px;height:72px;object-fit:cover;border:1px solid #ddd;border-radius:8px"><span>Open current image</span></a>` : '');
    expenseModal.show();
}

function loadDepartments(org,selected='',contact=''){
    $.get(DEPT_URL,r=>{
        let h='<option value="">No Department / Select Department</option>';
        r.forEach(v=>h+=`<option value="${v.id}" data-title="${esc(v.title)}" ${String(v.id)===String(selected)?'selected':''}>${esc(v.title)}</option>`);
        $('#department').html(h).trigger('change.select2');
        if(org) loadContacts(org,selected||'',contact);
    });
}
function loadContacts(org,dept='',selected=''){
    const data={}; if(dept) data.department_id=dept;
    $.get(CONTACT_URL+'/'+org,data,r=>{
        let h='<option value="">Select Contact</option>';
        r.forEach(v=>h+=`<option value="${v.id}" data-name="${esc(v.name)}" ${String(v.id)===String(selected)?'selected':''}>${esc(v.name||'Unnamed')}${v.designation?' - '+esc(v.designation.title):''}</option>`);
        $('#contact_id').html(h).trigger('change.select2');
    });
}

$(function(){
    // Move modals to <body> so parent theme transforms/filters cannot blur or block them.
    ['travelModal','expenseModal'].forEach(function(id){
        const el = document.getElementById(id);
        if(el && el.parentElement !== document.body){ document.body.appendChild(el); }
    });

    travelModal = new bootstrap.Modal(document.getElementById('travelModal'), {backdrop:true, keyboard:true, focus:true});
    expenseModal = new bootstrap.Modal(document.getElementById('expenseModal'), {backdrop:true, keyboard:true, focus:true});

    $('#department,#staff_id').each(function(){ if(this && !$(this).hasClass('select2-hidden-accessible')) $(this).select2({width:'100%',dropdownParent:$(this).closest('.modal').length?$(this).closest('.modal').find('.modal-content').first():$(document.body)}); });
    if($('#organization_id').hasClass('select2-hidden-accessible')) $('#organization_id').select2('destroy');
    $('#organization_id').select2({
        width:'100%', placeholder:'Search organization...', minimumInputLength:0,
        dropdownParent: $('#organization_id').closest('.modal').length ? $('#organization_id').closest('.modal').find('.modal-content').first() : $(document.body),
        ajax:{url:ORG_URL,dataType:'json',delay:300,data:p=>({q:p.term||'',page:p.page||1}),processResults:r=>r,cache:true}
    });
    if(OLD_ORG){
        $.ajax({url:ORG_URL,data:{q:'',page:1}}).always(()=>{});
        const oldText=@json($editing ? $activity->organization_name : '');
        $('#organization_id').append(new Option(oldText||('Organization #'+OLD_ORG),OLD_ORG,true,true)).trigger('change.select2');

    }

    loadDepartments(OLD_ORG,OLD_DEPT,OLD_CONTACT);
    $.get(VEHICLE_URL,r=>{ vehicles=r; fillVehicleOptions(''); });

    renderTravels(); renderExpenses();
});

$('#organization_id').on('change',function(){
    const v=$(this).val();
    if(v) loadContacts(v,$('#department').val());
});
$('#department').on('change',function(){
    const org=$('#organization_id').val(), d=$(this).val();
    if(org) loadContacts(org,d);
});

$('#addTravel').on('click',function(){ resetTravelModal(); travelModal.show(); });
$('#saveTravelRow').on('click',function(){
    const from=$.trim($('#travel_from').val()), to=$.trim($('#travel_to').val()), cost=parseFloat($('#travel_cost').val())||0;
    const travelDate=$('#travel_date').val(), travelTime=$('#travel_time').val();
    if(!travelDate || !travelTime){ Swal.fire('Required','TA date and time are required.','warning'); return; }
    if(!from || !to){ Swal.fire('Required','From and To location are required.','warning'); return; }
    if(cost < 0){ Swal.fire('Invalid','Travel cost cannot be negative.','warning'); return; }
    const idx=$('#travelEditIndex').val();
    const oldRow = idx==='' ? {} : (travels[parseInt(idx,10)] || {});
    const imageFile = document.getElementById('travel_image').files[0] || oldRow.image_file || null;
    const row={id:oldRow.id||null,edit_count:(oldRow.id && idx!=='' ? Number(oldRow.edit_count||0)+1 : Number(oldRow.edit_count||0)),_edited:(oldRow.id && idx!=='' ? true : !!oldRow._edited),last_edited_by_name:oldRow.last_edited_by_name||'',last_edited_at:oldRow.last_edited_at||'',entry_at:travelDate+'T'+travelTime,tour_type:$('#travel_tour_type').val()||'local_tour',from_location:from,to_location:to,vehicle:$('#travel_vehicle').val()||'',distance:parseFloat($('#travel_distance').val())||0,cost:cost,image_url:oldRow.image_url||'',image_view_url:oldRow.image_view_url||'',image_file:imageFile,image_preview_url:imageFile ? (oldRow.image_file===imageFile && oldRow.image_preview_url ? oldRow.image_preview_url : URL.createObjectURL(imageFile)) : ''};
    if(idx==='') travels.push(row); else travels[parseInt(idx,10)]=row;
    renderTravels(); travelModal.hide();
});
$(document).on('click','.edit-travel',function(){ openTravelEdit(parseInt($(this).data('index'),10)); });
$(document).on('click','.delete-travel',function(){
    const idx=parseInt($(this).data('index'),10);
    Swal.fire({title:'Delete this travel?',text:'This row will be removed from the activity.',icon:'warning',showCancelButton:true,confirmButtonText:'Delete'}).then(r=>{ if(r.isConfirmed){ travels.splice(idx,1); renderTravels(); } });
});

function updateBillRequired(){
    const required=String($('#expense_type option:selected').data('bill-required'))==='1';
    const idx=$('#expenseEditIndex').val();
    const row=idx===''?{}:(expenses[Number(idx)]||{});
    const needsUpload=required && !(row.image_url||row.image_view_url||row.image_preview_url);
    $('#expense_image').prop('required',needsUpload);
    $('#expense_image').closest('.col-12').find('label').html('DA / Cost Image'+(needsUpload?' <span class="required-mark">*</span>':''));
}
$('#expense_type').on('change',updateBillRequired);
$('#expenseModal').on('shown.bs.modal',updateBillRequired);
$('#addExpense').on('click',function(){ resetExpenseModal(); expenseModal.show(); });
$('#saveExpenseRow').on('click',function(){
    const typeId=$('#expense_type').val(), amount=parseFloat($('#expense_amount').val())||0;
    const expenseDate=$('#expense_date').val(), expenseTime=$('#expense_time').val();
    if(!expenseDate || !expenseTime){ Swal.fire('Required','DA date and time are required.','warning'); return; }
    if(!typeId){ Swal.fire('Required','Please select an expense type.','warning'); return; }
    if(amount < 0){ Swal.fire('Invalid','Amount cannot be negative.','warning'); return; }
    const idx=$('#expenseEditIndex').val();
    const oldRow = idx==='' ? {} : (expenses[parseInt(idx,10)] || {});
    const imageFile = document.getElementById('expense_image').files[0] || oldRow.image_file || null;
    const billRequired = String($('#expense_type option:selected').data('bill-required')) === '1';
    const hasExistingBill = !!(oldRow.image_url || oldRow.image_view_url || oldRow.image_preview_url);
    if(billRequired && !imageFile && !hasExistingBill){ Swal.fire('Bill Required','This expense type requires a bill/image. Please attach one.','warning'); return; }
    if(!travels.length){Swal.fire('TA Required','Please add the corresponding TA/travel entry before adding DA.','warning');return;}
    const row={id:oldRow.id||null,edit_count:(oldRow.id && idx!=='' ? Number(oldRow.edit_count||0)+1 : Number(oldRow.edit_count||0)),_edited:(oldRow.id && idx!=='' ? true : !!oldRow._edited),last_edited_by_name:oldRow.last_edited_by_name||'',last_edited_at:oldRow.last_edited_at||'',entry_at:expenseDate+'T'+expenseTime,expense_type_id:String(typeId),expense_type:$('#expense_type option:selected').data('name')||$('#expense_type option:selected').text(),amount:amount,note:$.trim($('#expense_note').val()),image_url:oldRow.image_url||'',image_view_url:oldRow.image_view_url||'',image_file:imageFile,image_preview_url:imageFile ? (oldRow.image_file===imageFile && oldRow.image_preview_url ? oldRow.image_preview_url : URL.createObjectURL(imageFile)) : ''};
    if(idx==='') expenses.push(row); else expenses[parseInt(idx,10)]=row;
    renderExpenses(); expenseModal.hide();
});
$(document).on('click','.edit-expense',function(){ openExpenseEdit(parseInt($(this).data('index'),10)); });
$(document).on('click','.delete-expense',function(){
    const idx=parseInt($(this).data('index'),10);
    Swal.fire({title:'Delete this cost?',text:'This row will be removed from the activity.',icon:'warning',showCancelButton:true,confirmButtonText:'Delete'}).then(r=>{ if(r.isConfirmed){ expenses.splice(idx,1); renderExpenses(); } });
});

$('#btnSave').on('click',function(){
    if(!$.trim($('#work_details').val())){ Swal.fire('Error','Visit Output is required','error'); return; }
    const fd=new FormData();
    if(CAN_MANAGE_ENTRY){
        fd.append('staff_id',$('#staff_id').val()||'');
        fd.append('activity_at',($('#activity_date').val()&&$('#activity_time').val()) ? $('#activity_date').val()+'T'+$('#activity_time').val() : '');
    }
    fd.append('organization_id',$('#organization_id').val());
    fd.append('department_id',$('#department').val());
    fd.append('department',$('#department').val() ? ($('#department option:selected').data('title')||$('#department option:selected').text()) : '');
    fd.append('contact_id','');
    fd.append('contact_person',$.trim($('#contact_person').val()));
    fd.append('work_details',$('#work_details').val());
    fd.append('remarks',$('#remarks').val());

    travels.forEach((r,i)=>{
        if(r.id) fd.append(`travels[${i}][id]`,r.id);
        if(r.id && r._edited) fd.append(`travels[${i}][_edited]`,'1');
        fd.append(`travels[${i}][entry_at]`,r.entry_at||'');
        fd.append(`travels[${i}][tour_type]`,r.tour_type||'local_tour');
        fd.append(`travels[${i}][from_location]`,r.from_location||'');
        fd.append(`travels[${i}][to_location]`,r.to_location||'');
        fd.append(`travels[${i}][vehicle]`,r.vehicle||'');
        fd.append(`travels[${i}][distance]`,r.distance||0);
        fd.append(`travels[${i}][cost]`,r.cost||0);
        fd.append(`travels[${i}][existing_image_url]`,r.image_url||'');
        if(r.image_file) fd.append(`travels[${i}][image]`,r.image_file);
    });
    expenses.forEach((r,i)=>{
        if(r.id) fd.append(`expenses[${i}][id]`,r.id);
        if(r.id && r._edited) fd.append(`expenses[${i}][_edited]`,'1');
        fd.append(`expenses[${i}][entry_at]`,r.entry_at||'');
        fd.append(`expenses[${i}][expense_type_id]`,r.expense_type_id||'');
        fd.append(`expenses[${i}][amount]`,r.amount||0);
        fd.append(`expenses[${i}][note]`,r.note||'');
        fd.append(`expenses[${i}][existing_image_url]`,r.image_url||'');
        if(r.image_file) fd.append(`expenses[${i}][image]`,r.image_file);
    });

    const btn=$(this), oldText=btn.text();
    btn.prop('disabled',true).text('Saving...');
    $.ajax({
        url:ACTIVITY_URL,type:'POST',data:fd,processData:false,contentType:false,
        success:r=>{
            btn.prop('disabled',false).text(oldText);
            Swal.fire('Success',r.message,'success').then(()=>{
                // Reload after an edit so newly-added TA/DA rows receive their persisted DB IDs
                // and each row's one-time edit lock is immediately based on server state.
                if(@json($editing)) {
                    window.location.reload();
                } else {
                    window.location.href=@json(route('activities.index'));
                }
            });
        },
        error:x=>{
            btn.prop('disabled',false).text(oldText);
            let m=x.responseJSON?.message||'Something went wrong';
            if(x.status===422&&x.responseJSON?.errors) m=Object.values(x.responseJSON.errors)[0][0];
            Swal.fire('Error',m,'error');
        }
    });
});
</script>
@endpush
