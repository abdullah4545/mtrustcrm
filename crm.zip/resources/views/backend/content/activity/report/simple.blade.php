@extends('backend.master')
@section('title', ($business?->business_name ?? 'Medi Trust Solution').' - '.($mode==='tour'?'Tour Report':'Activity Sort List'))
@section('maincontent')
@include('backend.partials.report-compact-summary')
<style>
.report-table-wrapper,.tour-table-wrap,.table-responsive{max-width:100%;overflow-x:auto}
#reportTable,.tour-report-table{width:100%;table-layout:fixed;min-width:1100px}
#reportTable th,#reportTable td,.tour-report-table th,.tour-report-table td,.table-responsive th,.table-responsive td{white-space:normal;overflow-wrap:anywhere;word-wrap:break-word;vertical-align:top}
#reportTable td div,.tour-report-table td div{max-width:100%;white-space:normal!important;overflow-wrap:anywhere}
</style>

@php
    $saved = session('crm_filter_sessions.'.md5(trim(request()->path(), '/')), []);
    $rf = function ($id, $default = '') use ($saved) {
        return $saved['id:'.$id] ?? $default;
    };
    $isTour = ($mode === 'tour');
    $reportUrls = $isTour ? [
        'data' => route('activities.tour-report.data'),
        'pdf' => route('activities.tour-report.pdf'),
        'print' => route('activities.tour-report.print'),
        'excel' => route('activities.tour-report.excel'),
    ] : [
        'data' => route('activities.sort-list.data'),
        'pdf' => route('activities.sort-list.pdf'),
        'print' => route('activities.sort-list.print'),
        'excel' => route('activities.sort-list.excel'),
    ];
@endphp
<div class="nxl-content"><div class="page-header"><div class="page-header-left"><div class="page-header-title"><h5 class="m-b-10">{{ $isTour?'Tour Report':'Activity Sort List' }}</h5></div></div></div>
<div class="main-content">
<div class="card"><div class="card-header"><h5 class="mb-0">Report Filters</h5></div><div class="card-body"><form id="reportFilterForm" data-persist-filters><div class="row g-3">
@if($isTour)
@can('staff.filter')<div class="col-md-4"><label class="form-label">Staff</label><select id="created_by" name="created_by" class="form-control"><option value="">All Staff</option>@foreach($users as $u)<option value="{{$u->id}}" @selected((string)$rf('created_by')===(string)$u->id)>{{$u->name}}</option>@endforeach</select></div>@endcan
<div class="col-md-3"><label class="form-label">From Date</label><input type="date" id="from_date" name="from_date" class="form-control" value="{{$rf('from_date',now()->startOfMonth()->format('Y-m-d'))}}"></div>
<div class="col-md-3"><label class="form-label">To Date</label><input type="date" id="to_date" name="to_date" class="form-control" value="{{$rf('to_date',now()->format('Y-m-d'))}}"></div>
@else
@can('staff.filter')<div class="col-md-3"><label class="form-label">Created By / User</label><select id="created_by" name="created_by" class="form-control"><option value="">All Users</option>@foreach($users as $u)<option value="{{$u->id}}" @selected((string)$rf('created_by')===(string)$u->id)>{{$u->name}}</option>@endforeach</select></div>@endcan
<div class="col-md-2"><label class="form-label">From Date</label><input type="date" id="from_date" name="from_date" class="form-control" value="{{$rf('from_date',now()->startOfMonth()->format('Y-m-d'))}}"></div>
<div class="col-md-2"><label class="form-label">To Date</label><input type="date" id="to_date" name="to_date" class="form-control" value="{{$rf('to_date',now()->format('Y-m-d'))}}"></div>
@if($canViewStatus)<div class="col-md-2"><label class="form-label">Status</label><select id="status" name="status" class="form-control"><option value="">All Status</option>@foreach(['pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $v=>$l)<option value="{{$v}}" @selected($rf('status')===$v)>{{$l}}</option>@endforeach</select></div>@endif
<div class="col-md-3"><label class="form-label">Payment Status</label><select id="payment_status" name="payment_status" class="form-control"><option value="">All Payment Status</option>@foreach(['unpaid'=>'Unpaid','waiting_for_payment'=>'Waiting for Payment','paid'=>'Paid'] as $v=>$l)<option value="{{$v}}" @selected($rf('payment_status')===$v)>{{$l}}</option>@endforeach</select></div>
@endif
<div class="col-12 d-flex gap-2"><button class="btn btn-primary" type="submit">Generate Report</button></div>
</div></form></div></div>
<div class="row g-3 mb-3 report-compact-summary"><div class="col-md-3"><div class="card"><div class="card-body"><small class="text-muted">{{ $isTour?'Total Tours':'Total Activities' }}</small><h3 id="count">0</h3></div></div></div><div class="col-md-3"><div class="card"><div class="card-body"><small class="text-muted">TA (Claimed)</small><h3 id="ta">0.00</h3></div></div></div><div class="col-md-3"><div class="card"><div class="card-body"><small class="text-muted">DA / Hotel / Others (Claimed)</small><h3 id="da">0.00</h3></div></div></div><div class="col-md-3"><div class="card"><div class="card-body"><small class="text-muted">Total Payable</small><h3 id="total">0.00</h3></div></div></div></div>
<div class="card"><div class="card-header d-flex justify-content-between flex-wrap gap-2"><h5 class="mb-0">{{ $isTour?'Tour Report':'Activity Sort List' }}</h5><div class="d-flex gap-2"><button id="excel" class="btn btn-success">Excel</button><button id="pdf" class="btn btn-danger">PDF</button><button id="print" class="btn btn-dark">Print</button></div></div><div class="card-body p-0"><div class="tour-table-wrap"><table class="table table-bordered mb-0 tour-report-table"><thead id="thead"></thead><tbody id="tbody"></tbody></table></div></div></div>
</div></div>
@endsection
<style>
.tour-table-wrap{width:100%;overflow-x:hidden}.tour-report-table{width:100%;table-layout:fixed}.tour-report-table th,.tour-report-table td{font-size:11px;padding:6px 5px;vertical-align:middle;white-space:normal;word-break:break-word}.tour-report-table th:nth-child(1),.tour-report-table td:nth-child(1){width:4%}.tour-report-table th:nth-child(2),.tour-report-table td:nth-child(2){width:13%}.tour-report-table th:nth-child(6),.tour-report-table td:nth-child(6),.tour-report-table th:nth-child(7),.tour-report-table td:nth-child(7),.tour-report-table th:nth-child(8),.tour-report-table td:nth-child(8){width:7%}@media(max-width:767px){.tour-table-wrap{overflow-x:auto}.tour-report-table{min-width:760px}}
</style>
@push('scripts')
<script>
const urls = {!! json_encode($reportUrls, JSON_UNESCAPED_SLASHES) !!};
const defaultColumns=@json($defaultColumns);
function params(){
    let p = new URLSearchParams();
    const filterIds = @if($isTour) ['created_by','from_date','to_date'] @else ['created_by','from_date','to_date','status','payment_status'] @endif;
    filterIds.forEach(id => {
        let e = document.getElementById(id);
        if (e && e.value) p.append(id, e.value);
    });
    defaultColumns.forEach(c => p.append('columns[]', c));
    return p;
}
async function load(){const r=await fetch(urls.data+'?'+params().toString(),{headers:{Accept:'application/json'}}); if(!r.ok){Swal.fire('Error','Could not load report.','error');return;} const d=await r.json(); document.getElementById('count').textContent=d.summary.count;document.getElementById('ta').textContent=d.summary.ta;document.getElementById('da').textContent=d.summary.da;document.getElementById('total').textContent=d.summary.total;document.getElementById('thead').innerHTML='<tr>'+d.columns.map(c=>`<th>${c.label}</th>`).join('')+'</tr>';document.getElementById('tbody').innerHTML=d.rows.length?d.rows.map(row=>'<tr>'+d.columns.map(c=>`<td>${['organization_name','from_location'].includes(c.key)&&row._html?.[c.key]?row._html[c.key]:String(row[c.key]??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}</td>`).join('')+'</tr>').join(''):`<tr><td colspan="${d.columns.length}" class="text-center py-4">No data found.</td></tr>`;}
$('#reportFilterForm').on('submit',e=>{e.preventDefault();window.CrmPersistentFilters?.saveNow();load();});
['excel','pdf','print'].forEach(k=>document.getElementById(k).addEventListener('click',()=>{let u=urls[k]+'?'+params().toString(); if(k==='print')window.open(u,'_blank');else window.location.href=u;}));
$(function(){ $('#created_by,#status,#payment_status').each(function(){if(this)$(this).trigger('change.select2')}); load(); });
</script>
@endpush
