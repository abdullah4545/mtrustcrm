@extends('backend.master')

@section('title')
    {{ ($business?->business_name ?? 'Medi Trust Solution') }} - Edit Quotation
@endsection

@section('maincontent')
<div class="nxl-content">

    <div class="page-header">
        <div class="page-header-left d-flex align-items-center">
            <div class="page-header-title">
                <h5 class="m-b-10">Edit Quotation</h5>
            </div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                <li class="breadcrumb-item">CRM</li>
                <li class="breadcrumb-item"><a href="{{ route('quotations.index') }}">Quotations</a></li>
                <li class="breadcrumb-item">{{ $q->quotation_no }}</li>
            </ul>
        </div>

        <div class="page-header-right ms-auto d-flex gap-2">
            <a href="{{ route('quotations.show',$q->id) }}" class="btn btn-secondary"><i class="feather-eye me-1"></i> View</a>
            <a href="{{ route('quotations.pdf',$q->id) }}" class="btn btn-dark"><i class="feather-download me-1"></i> PDF</a>
            <a href="{{ route('quotations.index') }}" class="btn btn-light-brand">Back</a>
        </div>
    </div>

    @if(session('message'))
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('message') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="main-content">
        <div class="card">
            <div class="card-body">

                <form method="POST" action="{{ route('quotations.update',$q->id) }}" id="quotationForm">
                    @csrf

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Quotation No</label>
                            <input class="form-control" value="{{ $q->quotation_no }}" readonly>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Client Name</label>
                            <input class="form-control" name="client_name" value="{{ $q->client_name }}">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Valid Till</label>
                            <input type="date" class="form-control" name="valid_until" value="{{ optional($q->valid_until)->format('Y-m-d') }}">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Client Phone</label>
                            <input class="form-control" name="client_phone" value="{{ $q->client_phone }}">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Client Email</label>
                            <input class="form-control" name="client_email" value="{{ $q->client_email }}">
                        </div>

                        <div class="col-md-8">
                            <label class="form-label">Client Address</label>
                            <input class="form-control" name="client_address" value="{{ $q->client_address }}">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Issue Date</label>
                            <input type="date" class="form-control" name="issue_date" value="{{ optional($q->issue_date)->format('Y-m-d') }}">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Currency</label>
                            <select class="form-control" name="currency">
                                <option value="BDT" {{ $q->currency=='BDT'?'selected':'' }}>BDT (৳)</option>
                                <option value="USD" {{ $q->currency=='USD'?'selected':'' }}>USD ($)</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Calculate Tax</label>
                            <select class="form-control" name="calculate_tax">
                                <option value="after_discount" {{ $q->calculate_tax=='after_discount'?'selected':'' }}>After Discount</option>
                                <option value="before_discount" {{ $q->calculate_tax=='before_discount'?'selected':'' }}>Before Discount</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label d-block">VAT / Tax</label>
                            <div class="form-check mt-2">
                                <input type="hidden" name="tax_enabled" value="0">
                                <input class="form-check-input" type="checkbox" name="tax_enabled" id="tax_enabled" value="1" {{ $q->tax_enabled ? 'checked' : '' }}>
                                <label class="form-check-label" for="tax_enabled">Include VAT / Tax ({{ number_format($taxRate,2) }}%)</label>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select class="form-control" name="status_stage_id">
                                <option value="">--</option>
                                @foreach($statuses as $s)
                                    <option value="{{ $s->id }}" {{ $q->status_stage_id==$s->id?'selected':'' }}>{{ $s->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-8">
                            <label class="form-label">Quotation Subject</label>
                            <input class="form-control" name="subject" value="{{ $q->subject }}" placeholder="e.g. Supply of Medical Equipment">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Salutation</label>
                            <input class="form-control" name="salutation" value="{{ $q->salutation ?: 'Dear Sir,' }}">
                        </div>

                        <div class="col-md-12">
                            <label class="form-label">Cover Letter</label>
                            <textarea class="form-control quotation-editor" id="cover_letter" name="cover_letter" rows="6">{!! $q->cover_letter !!}</textarea>
                        </div>

                        <div class="col-md-12">
                            <label class="form-label">Quotation Description / Additional Details</label>
                            <textarea class="form-control" name="description" rows="3">{{ $q->description }}</textarea>
                        </div>

                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="1" name="require_signature" id="require_signature" {{ $q->require_signature ? 'checked':'' }}>
                                <label class="form-check-label" for="require_signature">Require customer signature for approval</label>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0">Items</h6>
                        <button type="button" class="btn btn-sm btn-primary" id="btnAddRow">
                            <i class="feather-plus"></i> Add Item
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered align-middle" id="itemsTable">
                            <thead>
                                <tr>
                                    <th width="240">Product/Custom Item</th>
                                    <th>Description</th>
                                    <th width="90">Qty</th>
                                    <th width="90">Unit</th>
                                    <th width="120">Unit Price</th>
                                    <th width="90">Tax %</th>
                                    <th width="130">Amount</th>
                                    <th width="50"></th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-6">
                            <label class="form-label">Note for Recipient</label>
                            <textarea class="form-control quotation-editor" id="note_for_recipient" name="note_for_recipient" rows="3">{!! $q->note_for_recipient !!}</textarea>

                            <label class="form-label mt-3">Terms Section Title</label>
                            <input class="form-control" name="terms_title" value="{{ $q->terms_title ?: 'TERMS AND CONDITIONS' }}">

                            <label class="form-label mt-3">Terms & Conditions</label>
                            <textarea class="form-control quotation-editor" id="terms" name="terms" rows="7">{!! $q->terms !!}</textarea>

                            <label class="form-label mt-3">Closing / Final Note</label>
                            <textarea class="form-control quotation-editor" id="closing_note" name="closing_note" rows="3">{!! $q->closing_note !!}</textarea>

                            <label class="form-label mt-3">Regards / Sign-off</label>
                            <input class="form-control" name="sign_off" value="{{ $q->sign_off ?: 'Best Regards' }}">
                        </div>

                        <div class="col-md-6">
                            <div class="border rounded p-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Sub Total</span>
                                    <b id="subTotalText">0.00</b>
                                </div>

                                <div class="d-flex justify-content-between mb-2 align-items-center">
                                    <span>Discount</span>
                                    <input type="number" step="0.01" class="form-control" name="discount_amount" id="discount_amount" value="{{ $q->discount_amount }}" style="width:160px;">
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax</span>
                                    <b id="taxText">0.00</b>
                                </div>

                                <hr>

                                <div class="d-flex justify-content-between">
                                    <span>Total</span>
                                    <b id="grandTotalText">0.00</b>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 d-flex gap-2">
                        <button class="btn btn-primary">Update</button>
                        <a href="{{ route('quotations.index') }}" class="btn btn-light-brand">Cancel</a>
                    </div>

                </form>

            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script>
const quotationEditors = {};
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.quotation-editor').forEach(el => {
        ClassicEditor.create(el, { toolbar: ['heading','|','bold','italic','link','bulletedList','numberedList','|','undo','redo'] })
            .then(editor => { quotationEditors[el.id] = editor; })
            .catch(console.error);
    });
    document.getElementById('quotationForm')?.addEventListener('submit', () => {
        Object.entries(quotationEditors).forEach(([id, editor]) => {
            const source = document.getElementById(id);
            if(source) source.value = editor.getData();
        });
    });
});
</script>
<script>
const PRODUCT_OPTIONS_URL = "{{ route(name: 'products.options') }}";
const GLOBAL_TAX_RATE = Number(@json($taxRate ?? 0));
const PRODUCT_DETAILS_URL = "{{ url('products') }}"; // /{id}/details

let rowIndex = 0;
const EXISTING_ITEMS = @json($q->items);

document.addEventListener('DOMContentLoaded', () => {
    // load existing rows
    if(EXISTING_ITEMS && EXISTING_ITEMS.length){
        EXISTING_ITEMS.forEach(it => addRow(it));
    }else{
        addRow();
    }

    document.getElementById('btnAddRow').addEventListener('click', () => addRow());
    document.getElementById('discount_amount').addEventListener('input', calcTotals);
document.getElementById('tax_enabled')?.addEventListener('change', calcTotals);
document.querySelector('[name=calculate_tax]')?.addEventListener('change', calcTotals);

    calcTotals();
});

function addRow(item = null){
    const tbody = document.querySelector('#itemsTable tbody');
    const idx = rowIndex++;
    const tr = document.createElement('tr');
    tr.dataset.idx = idx;

    tr.innerHTML = `
        <td>
            <select class="form-control product_id" name="items[${idx}][product_id]">
                <option value="">-- Custom Item --</option>
            </select>
            <input class="form-control mt-2 item_name" name="items[${idx}][item_name]" placeholder="Item name *" required>
        </td>
        <td>
            <textarea class="form-control item_desc" name="items[${idx}][description]" rows="2" placeholder="Description (optional)"></textarea>
        </td>
        <td><input type="number" step="0.01" class="form-control qty" name="items[${idx}][qty]" value="1"></td>
        <td><input type="text" class="form-control unit" name="items[${idx}][unit]" value="pcs"></td>
        <td><input type="number" step="0.01" class="form-control unit_price" name="items[${idx}][unit_price]" value="0"></td>
        <td><input type="number" step="0.01" class="form-control tax_rate" name="items[${idx}][tax_rate]" value="0"></td>
        <td><b class="line_total_text">0.00</b></td>
        <td class="text-center">
            <button type="button" class="btn btn-sm btn-danger btn-remove">&times;</button>
        </td>
    `;

    tbody.appendChild(tr);

    loadProducts(tr, item?.product_id ?? null).then(() => {
        // set values
        if(item){
            tr.querySelector('.item_name').value = item.item_name ?? '';
            tr.querySelector('.item_desc').value = item.description ?? '';
            tr.querySelector('.qty').value = item.qty ?? 1;
            tr.querySelector('.unit').value = item.unit ?? 'pcs';
            tr.querySelector('.unit_price').value = item.unit_price ?? 0;
            tr.querySelector('.tax_rate').value = item.tax_rate ?? 0;
        }
        calcTotals();
    });

    tr.querySelector('.btn-remove').addEventListener('click', () => {
        tr.remove();
        calcTotals();
    });

    ['input','change'].forEach(ev => {
        tr.querySelector('.qty').addEventListener(ev, calcTotals);
        tr.querySelector('.unit_price').addEventListener(ev, calcTotals);
        tr.querySelector('.tax_rate').addEventListener(ev, calcTotals);
        tr.querySelector('.item_name').addEventListener(ev, calcTotals);
    });

    tr.querySelector('.product_id').addEventListener('change', async (e) => {
        const pid = e.target.value;
        if(!pid) return;
        const res = await fetch(`${PRODUCT_DETAILS_URL}/${pid}/details`);
        const json = await res.json();
        if(json.status){
            const d = json.data;
            tr.querySelector('.item_name').value = d.name || '';
            tr.querySelector('.unit_price').value = d.sale_price || 0;
            tr.querySelector('.item_desc').value = d.description || d.configuration_description || '';
            tr.querySelector('.tax_rate').value = document.getElementById('tax_enabled')?.checked ? GLOBAL_TAX_RATE : 0;
            calcTotals();
        }
    });
}

async function loadProducts(tr, selectedId=null){
    const sel = tr.querySelector('.product_id');
    const res = await fetch(PRODUCT_OPTIONS_URL);
    const rows = await res.json();

    let html = `<option value="">-- Custom Item --</option>`;
    rows.forEach(r => {
        html += `<option value="${r.id}">${escapeHtml(r.name)}</option>`;
    });
    sel.innerHTML = html;
    if(selectedId) sel.value = selectedId;
}

function calcTotals(){
    let sub = 0;
    let tax = 0;

    document.querySelectorAll('#itemsTable tbody tr').forEach(tr => {
        const qty = parseFloat(tr.querySelector('.qty').value || 0);
        const price = parseFloat(tr.querySelector('.unit_price').value || 0);
        const rate = document.getElementById('tax_enabled')?.checked ? GLOBAL_TAX_RATE : 0;
        tr.querySelector('.tax_rate').value = rate;

        const base = qty * price;
        const taxAmount = rate > 0 ? (base * rate / 100) : 0;
        const line = base + taxAmount;

        tr.querySelector('.line_total_text').innerText = line.toFixed(2);
        sub += base;
        tax += taxAmount;
    });

    const discount = parseFloat(document.getElementById('discount_amount').value || 0);
    const mode = document.querySelector('[name=calculate_tax]')?.value || 'after_discount';
    const taxBase = mode === 'before_discount' ? sub : Math.max(0, sub - discount);
    tax = document.getElementById('tax_enabled')?.checked ? (taxBase * GLOBAL_TAX_RATE / 100) : 0;
    const grand = Math.max(0, sub - discount) + tax;

    document.getElementById('subTotalText').innerText = sub.toFixed(2);
    document.getElementById('taxText').innerText = tax.toFixed(2);
    document.getElementById('grandTotalText').innerText = grand.toFixed(2);
}

function escapeHtml(text){
  return (text ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
</script>
@endpush
